//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//
#ifndef _STEREOH
#define _STEREOH

#include "main.h"

using namespace std;
using namespace cv;

// results are gray disparity map
extern Mat do_StereoBM(Mat *imgL, Mat *imgR, Mat *disp32F);
extern Mat do_StereoSGBM(Mat *imgL, Mat *imgR, Mat *disp32F);

extern void resetParams_Stereo();
extern void saveParams_Stereo();
extern void loadParams_Stereo();

#endif
