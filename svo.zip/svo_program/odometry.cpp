//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 	
 * Filter untuk features dengan menggunakan disparity map
 * 
 * Menghitung pose berdasarkan 2D/3D Correspondence
 * menggunakan fungsi SolvePnP() dari OpenCV
 * metodenya: ITERATIVE , P3P , 
 * 
 * Rekonstruksi matrix Q dari Projection matrix
 */
//

#include "odometry.h"

// create Q 4x4 perpective matrix from projection matrix 3x4
Mat OdoCreateQ(Mat * projMatL, Mat * projMatR)
{
	Mat result(Size(4,4), CV_32FC1); // float
	result.setTo( 0.0f ); // convert all into zeroes value
	
	// -cx
	float cxL = (*projMatL).at<float>(0,2);
	float cxR = (*projMatR).at<float>(0,2);
	result.at<float>(0,0) = -1 * cxL;
	// -cy
	result.at<float>(0,0) = -1 * (*projMatL).at<float>(1,2);
	// focal
	result.at<float>(0,0) = (*projMatL).at<float>(0,0);
	// -1/baseline
	result.at<float>(0,0) = 1 / (*projMatR).at<float>(0,3);
	// disparity_x/baseline
	result.at<float>(0,0) = (cxL - cxR) / (-1*(*projMatR).at<float>());
	
	// identity points
	result.at<float>(0,0) = 1;
	result.at<float>(1,1) = 1;
	
	return result;
}

// Filter features using disparity map!
// destroy/kill features that have -1 disparity value!
void OdoFilterFeatures(Mat * disp32F, vector<Point2f> *prev_features, vector<Point2f> *features, bool *flow_pass )
{
	if((*disp32F).data == NULL || (*prev_features).size() <= 0)
	{
		return;
	}
	
	vector<Point2f> newPrevTemp;
	vector<Point2f> newTemp;
	
	// # FILTER USING DISPARITY MAP
	// process previous frame features ( t-1 )
	newPrevTemp.clear();
	newTemp.clear();
	for(size_t i = 0 ; i < (*prev_features).size() ; i++)
	{
		Point2f cur = (*prev_features)[i];
		float dispVal = (*disp32F).at<float>( cur.y , cur.x );
		
		// if the features doesn't have depth/distance then mark for removal
		if(dispVal <= 0)
		{
			// don't add into new feature storage!
			continue;
		}
		
		// check for min/max filtering
		// using manual Z calculation
		bool stereo_filter = chkStereoFilter->value();
		double minZ = strtod(txtStereoMinZ->value(),NULL);
		double maxZ = strtod(txtStereoMaxZ->value(),NULL);
		double B_fx = ProjectR.at<double>(0,3); // baseline * focal length x   <-- taken from projMatrixR
		double Z_chk = fabs((B_fx) / (double)dispVal);
		if( ((Z_chk < minZ) || (Z_chk > maxZ)) && (stereo_filter == true) )
		{
			//cout << "Filtered min/max Z! ; valueZ = " << Z_chk << endl;
			// don't add into new feature storage!
			continue;
		}
		
		// add into storage of features and prev_features
		newPrevTemp.push_back( cur );
		newTemp.push_back( (*features)[i] );
	}
	(*prev_features) = newPrevTemp; // copy
	(*features) = newTemp; // copy
	
	// # FILTER, OUTLIERS REMOVAL using RANSAC
	// # GET OPTICAL FLOW FEATURES MEAN DISTANCE 
	double acc_distance = 0.0;
	double flow_threshold = 0;
	if(strlen(txtSmallOFThreshold->value()) > 0)
	{
		flow_threshold = strtod(txtSmallOFThreshold->value(),NULL);
	}
	*flow_pass = false;
	bool use_RANSAC = chkRANSACOutliers->value();
	double RANSAC_threshold = strtod(txtRANSACThreshold->value(),NULL);
	if(use_RANSAC == true && ((*prev_features).size() > 0) && ((*features).size() > 0))
	{
		Mat mask; // CV_8UC1
		findHomography( *prev_features, *features, CV_RANSAC, RANSAC_threshold, mask );
		newPrevTemp.clear();
		newTemp.clear();
		for(size_t i = 0 ; i < (*prev_features).size() ; i++)
		{
			unsigned char mask_val = mask.at<unsigned char>(i,0);
			if(mask_val >= 1)
			{
				// add features
				newPrevTemp.push_back( (*prev_features)[i] );
				newTemp.push_back( (*features)[i] );
				
				// calc distance
				acc_distance += sqrt(
										pow(((*features)[i].x - (*prev_features)[i].x) ,2) +
										pow(((*features)[i].y - (*prev_features)[i].y) ,2)
								);
			}
		}
		// pass/copy
		(*prev_features) = newPrevTemp; // copy
		(*features) = newTemp; // copy
		
		// calculate total distance (mean)
		acc_distance = (acc_distance / (double)(*features).size());
		cout << "Mean distance of optical flow = " << acc_distance << endl;
		if(acc_distance >= flow_threshold)
		{
			*flow_pass = true;
		}
	}
}

// Triangulate 2D features into 3D features by using Q matrix from stereoCalibrate!
void OdoTriangulate( Mat * ProjL , Mat * ProjR , Mat * Q , Mat * disp32F, vector<Point2f> *features2D, vector<Point3f> *outfeatures3D , int mode )
{
	if((*disp32F).data == NULL || (*features2D).size() <= 0)
	{
		return;
	}
	
	// triangulate by using *disparity and projection matrices
	if(mode == 0)
	{
		// WARNING: (CHANGE LATED BY FEATURES-MATCHING/TRACKER , bypass this)
		// Prepare right points by using left points + disparity pixel
		vector<Point2f> RightPts;
		for(size_t i = 0 ; i < (*features2D).size() ; i++)
		{
			Point2f cur = (*features2D)[i];
			float value_disparity = (*disp32F).at<float>( cur.y , cur.x );
			RightPts.push_back( Point2f(cur.x+value_disparity, cur.y) );
		}
		
		// Triangulate points + Projection Mat
		Mat Out4D(Size(4,1),CV_32FC1);
		triangulatePoints(
			*ProjL,
			*ProjR,
			*features2D,
			RightPts,
			Out4D
		);
		// Converting from homogeneous coordinates
		vector<Point3f> new3D;
		for(int i = 0 ; i < Out4D.size().width ; i++)
		{
			// calc and scale
			float Ww = Out4D.at<float>(3,i); // scaling factor
			float Wx = -1 * Out4D.at<float>(0,i) / Ww; // X
			float Wy = -1 * Out4D.at<float>(1,i) / Ww; // Y
			float Wz = -1 * Out4D.at<float>(2,i) / Ww; // Z
			// add
			new3D.push_back( Point3f( Wx, Wy, Wz ) );
		}
		*outfeatures3D = new3D;
	}
	
	// triangulate using full disparity map projection into 3D
	// warning: slow
	if(mode == 1)
	{
		// ReprojectImage from disparity map + Q
		Mat resImg3D( (*disp32F).size(), CV_32FC4 );
		reprojectImageTo3D(
			*disp32F,
			*outfeatures3D,
			*Q,
			false,	// handle missing values. if true (disp=-1) -> Z returned in +10000
			CV_32F
		);
		//Point3f atPt = resImg3D.at<Point3f>(ms_y, ms_x);
		//Wz = atPt.z;
		//Wx = atPt.x;
		//Wy = atPt.y;
	}
}

void OdoDrawFeatures(Mat *img, vector<Point2f> *prev_features, vector<Point2f> *features)
{
	if((*prev_features).size()>0 && (*features).size()>0)
	{		
		for(size_t i = 0; i < (*features).size() ; i++)
		{	
			// set points for drawing
			Point fromPt( (*prev_features)[i].x , (*prev_features)[i].y );
			Point toPt( (*features)[i].x , (*features)[i].y );
			
			// GREEN
			Scalar warna(0,255,0);
			
			// draw displacement with line
			line( *img, fromPt, toPt, warna, 1, LINE_8 );
			// draw end array with small circle
			circle( *img, toPt , 3, warna , 1 );	
		}
	} else {
		// draw individual features
		for(size_t i = 0; i < (*prev_features).size() ; i++)
		{	
			// set points for drawing
			Point featurePt( (*prev_features)[i].x , (*prev_features)[i].y );
			// BLUE
			Scalar warna(255,0,0);
			// draw end array with small circle
			circle( *img, featurePt , 3, warna , 1 );	
		}
		for(size_t i = 0; i < (*features).size() ; i++)
		{	
			// set points for drawing
			Point featurePt( (*features)[i].x , (*features)[i].y );
			// RED
			Scalar warna(0,0,255);
			// draw end array with small circle
			circle( *img, featurePt , 3, warna , 1 );	
		}
	}
}


// reset settings
void resetParams_Odo()
{
	op3DProjectionMat->value(1);
	op3DDisparityMap->value(0);
	chkUseCustomExterinsic->value(0);
	cmbPNPFlag->value(0);
	txtBaseline->value("");
	chkKeyframeFiltering->value(0);
	txtMinKeyframeFeatures->value("");
	chkStereoFilter->value(0);
	txtStereoMinZ->value("");
	txtStereoMaxZ->value("");
	chkIgnoreSmallOF->value(0);
	txtSmallOFThreshold->value("");
	chkSaveOdo->value(0);
	txtOdoPoseFile->value("");
	chkKITTI->value(0);
	txtKITTIposeFile->value("");
}

// save settings
void saveParams_Odo()
{
	// create root setting point
	Fl_Preferences settings = Fl_Preferences( ".", "Jonathan Chandra OpenCV 2016", "Odometry" );
	settings.set("AppVersion", "0.1");
	settings.set("Copyright", "Jonathan Chandra (c) 2016");

	// create sub-child
	Fl_Preferences Odo = Fl_Preferences( settings, "Odo" );
		Odo.set("optionProjection3D",op3DProjectionMat->value());
		Odo.set("optionDisparity3D",op3DDisparityMap->value());
		Odo.set("useExterinsic",chkUseCustomExterinsic->value());
		Odo.set("baseline",txtBaseline->value());
		Odo.set("PnPMode",cmbPNPFlag->value());
		Odo.set("KeyframeFiltering",chkKeyframeFiltering->value());
		Odo.set("MinFeaturesKeyframe",txtMinKeyframeFeatures->value());
		Odo.set("useKITTI",chkKITTI->value());
		Odo.set("KITTIposeFile", txtKITTIposeFile->value());
		Odo.set("stereoFilter",chkStereoFilter->value());
		Odo.set("stereoMinZ",txtStereoMinZ->value());
		Odo.set("stereoMaxZ",txtStereoMaxZ->value());
		Odo.set("IgnoreSmallOF",chkIgnoreSmallOF->value());
		Odo.set("SmallOFThreshold",txtSmallOFThreshold->value());
		Odo.set("SaveOdo",chkSaveOdo->value());
		Odo.set("OdoPoseFile",txtOdoPoseFile->value());
	
}

// load settings
void loadParams_Odo()
{
	int ival;
	double dval;
	char tmpstr[100];
	
	// create root setting point
	Fl_Preferences settings = Fl_Preferences( ".", "Jonathan Chandra OpenCV 2016", "Odometry" );
	settings.set("AppVersion", "0.1");
	settings.set("Copyright", "Jonathan Chandra (c) 2016");

	// create sub-child
	Fl_Preferences Odo = Fl_Preferences( settings, "Odo" );
		Odo.get("optionProjection3D",ival,1);
			op3DProjectionMat->value(ival);
		Odo.get("optionDisparity3D",ival,0);
			op3DDisparityMap->value(ival);
		Odo.get("useExterinsic",ival,0);
			chkUseCustomExterinsic->value(ival);
		Odo.get("baseline",dval,0.0);
			if(dval != 0.0) {
				sprintf(tmpstr,"%lf",dval);
				txtBaseline->value(tmpstr);
			}
		Odo.get("PnPMode",ival,0);
			cmbPNPFlag->value(ival);
		Odo.get("KeyframeFiltering",ival,1);
			chkKeyframeFiltering->value(ival);
		Odo.get("MinFeaturesKeyframe",dval,0.0);
			if(dval != 0.0)
			{
				sprintf(tmpstr,"%lf",dval);
				txtMinKeyframeFeatures->value(tmpstr);
			}
		Odo.get("stereoFilter",ival,0);
			chkStereoFilter->value(ival);
		Odo.get("stereoMinZ",dval,0.0);
			if(dval != 0.0)
			{
				sprintf(tmpstr,"%lf",dval);
				txtStereoMinZ->value(tmpstr);
			}
		Odo.get("stereoMaxZ",dval,0.0);
			if(dval != 0.0)
			{
				sprintf(tmpstr,"%lf",dval);
				txtStereoMaxZ->value(tmpstr);
			}
		Odo.get("IgnoreSmallOF",ival,0);
			chkIgnoreSmallOF->value(ival);
		Odo.get("SmallOFThreshold",dval,0.0);
			if(dval > 0.0)
			{
				sprintf(tmpstr, "%lf", dval);
				txtSmallOFThreshold->value(tmpstr);
			}
		Odo.get("SaveOdo",ival,0);
			chkSaveOdo->value(ival);
		Odo.get("OdoPoseFile",tmpstr,"",99);
			txtOdoPoseFile->value(tmpstr);
		Odo.get("useKITTI",ival,1);
			chkKITTI->value(ival);
		Odo.get("KITTIposeFile", tmpstr, "", 99);
			txtKITTIposeFile->value(tmpstr);
	
}


