//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//
#ifndef _FLOWH
#define _FLOWH

#include "main.h"

using namespace std;
using namespace cv;

extern void detect_features(Mat *img, vector<Point2f> *features);
extern Mat do_OpticalFlow(Mat * prev_img, Mat *img, vector<Point2f> *prev_features, vector<Point2f> *features);

extern void resetParams_Flow();
extern void saveParams_Flow();
extern void loadParams_Flow();

#endif
