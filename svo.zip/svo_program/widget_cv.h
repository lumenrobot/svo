//
/*
 *	FLTK TEMPLATE
 *  # OpenCV Widget #
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#ifndef _FL_CVDRAWING
#define _FL_CVDRAWING
//----------------------------------------------------------------------

#include "fltk.h" // including all FLTK includes
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/videoio/videoio.hpp>
#include <opencv2/calib3d/calib3d.hpp>

using namespace std;
using namespace cv;

class Fl_CV_Drawing : public Fl_Box {
	public:
		Mat * source; // = null;
		bool enable; // = false;
	protected:
		void draw();
		int handle(int e);
	public:
		Fl_CV_Drawing(int X,int Y,int W,int H,const char*L=0) : Fl_Box(X,Y,W,H,L) { source = NULL; enable = false; }; 
		~Fl_CV_Drawing() {}; 
};

//----------------------------------------------------------------------
#endif
