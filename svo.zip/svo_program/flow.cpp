//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 
 * 2D Features detection (Good/Fast)	
 * OpticalFlow , KLT Tracker. KanadeLucasTomashi
 * 
 */
//

#include "flow.h"

using namespace std;
using namespace cv;

// KLT OpticalFlow
Mat do_OpticalFlow(Mat * prev_img, Mat *img, vector<Point2f> *prev_features, vector<Point2f> *features)
{
	if((*prev_img).data == NULL || (*img).data == NULL)
	{
		return Mat();
	}
	
	Mat result;
	result = (*img).clone();
	int OF_winSize = strtol(txtOFWinSize->value(),NULL,10);
	int OF_maxLevel = strtol(txtOFMaxLevel->value(),NULL,10);
	int OF_iter = strtol(txtOFIteration->value(),NULL,10);
	double OF_eps = strtod(txtOFEPS->value(),NULL);
	
	// # convert prev frame to gray
	Mat prev_gray_frame;
	cvtColor( *prev_img, prev_gray_frame, CV_BGR2GRAY );
	
	// # convert current frame to gray
	Mat gray_frame;
	cvtColor( *img, gray_frame, CV_BGR2GRAY );
	
	// # Optical flow
	vector<unsigned char> out_status;
	vector<float> out_error;
	TermCriteria flowCriteria( CV_TERMCRIT_ITER | CV_TERMCRIT_EPS, OF_iter, OF_eps );
	if( (*features).size() > 0 && (*prev_features).size() > 0)
	{
		calcOpticalFlowPyrLK(
			prev_gray_frame, 	// prevImg
			gray_frame,			// nextImg
			*prev_features,		// prevPts
			*features,			// nextPts
			out_status,			// output, status [unsigned char]
			out_error,			// output, error [float]
			Size(OF_winSize,OF_winSize),		// winSize
			OF_maxLevel,			// maxLevel
			flowCriteria,		// criteria
			0					// flags
			// (default)		// minEigThreshold
		);
	}
	
	// # draw + count optical flow
	vector<Point2f> newvec_features; newvec_features.clear();
	vector<Point2f> newvec_prev_features; newvec_prev_features.clear();
	if((*prev_features).size()>0 || (*features).size()>0)
	{
		//cout << "Reordering... " << endl;
		
		for(size_t i = 0; i < out_status.size() ; i++)
		{
			// if not found
			if(out_status[i] == 0)
			{
				continue;
			}
			
			// add points to new vectors
			newvec_prev_features.push_back( (*prev_features)[i] );
			newvec_features.push_back( (*features)[i] );
			
			// set points for drawing
			Point fromPt( (*prev_features)[i].x , (*prev_features)[i].y );
			Point toPt( (*features)[i].x , (*features)[i].y );
			
			// GREEN
			// draw optical flow
			Scalar warna(0,255,0);
			if(i == 0) { warna = Scalar(0,0,255); }
			line( result, fromPt, toPt, warna, 1, LINE_8 );
			
			// GREEN
			// draw end array with small circle
			circle( result, toPt , 3, warna , 1 );
			
		}
	}
	
	// return as new counted real-size features
	(*features) = newvec_features;
	(*prev_features) = newvec_prev_features;
	
	// WARNING, IN THE END OF YOUR CODE, YOU MUST DO THESE :
	// you must pass prev_features = features !!
	// and last_frame = frame !!
	
	return result;
}


// Feature 2D detection
void detect_features(Mat *img, vector<Point2f> *features)
{
	
	int GOOD_n = strtol(txtGOODNumFeatures->value(),NULL,10);
	double GOOD_minQ = strtod(txtGOODMinQuality->value(),NULL);
	double GOOD_minED = strtod(txtGOODEDistance->value(),NULL);
	int GOOD_bsize = strtol(txtGOODBlockSize->value(),NULL,10);
	bool GOOD_harris = chkGOODHarris->value();
	double GOOD_kParam = strtod(txtGOODkParameter->value(),NULL);
	
	// [GOOD / HARRIS]
	if(opFeaturesGOOD->value() == 1)
	{
		goodFeaturesToTrack(
			*img, //gray_frame,
			*features,	// output
			GOOD_n,		// max corners
			GOOD_minQ,	// min quality
			GOOD_minED,	// min euclidean distance
			Mat(),		// mask NO
			GOOD_bsize,	// block size, default 3
			GOOD_harris,	// use HARRIS
			GOOD_kParam	// HARRIS free parameter
		);
	}
	
	int FAST_threshold = strtol(txtFASTThreshold->value(),NULL,10);
	bool FAST_NMAXSup = chkFASTNonMaxSup->value();
	
	// [FAST]
	if(opFeaturesFAST->value() == 1)
	{
		vector<KeyPoint> out_keypoints;
		FAST(
			*img, //gray_frame,
			out_keypoints,
			FAST_threshold,
			FAST_NMAXSup
		);

		// convert keypoints to point2f
		KeyPoint::convert(out_keypoints, *features);
	}
	
}

// reset settings
void resetParams_Flow()
{
	txtOFWinSize->value("3");
	txtOFMaxLevel->value("5");
	txtOFIteration->value("20");
	txtOFEPS->value("0.3");
	chkOFThresholding->value(1);
	txtOFMinFeatures->value("400");
	chkRANSACOutliers->value(1);
	txtRANSACThreshold->value("3");
	
	txtGOODNumFeatures->value("1000");
	txtGOODMinQuality->value("0.01");
	txtGOODEDistance->value("0.01");
	txtGOODBlockSize->value("5");
	txtGOODkParameter->value("0.04");
	chkGOODHarris->value(0);
	txtFASTThreshold->value("15");
	chkFASTNonMaxSup->value(1);
	opFeaturesGOOD->value(1);
	opFeaturesFAST->value(0);
}

// save settings
void saveParams_Flow()
{
	// create root setting point
	Fl_Preferences settings = Fl_Preferences( ".", "Jonathan Chandra OpenCV 2016", "OpticalFlow" );
	settings.set("AppVersion", "0.1");
	settings.set("Copyright", "Jonathan Chandra (c) 2016");

	// create sub-child
	Fl_Preferences OF = Fl_Preferences( settings, "OF" );
		OF.set("winSize",txtOFWinSize->value());
		OF.set("MaxLevel",txtOFMaxLevel->value());
		OF.set("Iteration",txtOFIteration->value());
		OF.set("EPS",txtOFEPS->value());
		OF.set("Thresholding",chkOFThresholding->value());
		OF.set("MinFeatures",txtOFMinFeatures->value());
		OF.set("UseRANSACOutliers",chkRANSACOutliers->value());
		OF.set("RANSACThreshold",txtRANSACThreshold->value());

	settings.set("opGOOD",opFeaturesGOOD->value());
	settings.set("opFAST",opFeaturesFAST->value());

	// create sub-child
	Fl_Preferences GOOD = Fl_Preferences( settings, "GOOD" );
		GOOD.set("nFeatures",txtGOODNumFeatures->value());
		GOOD.set("minQ",txtGOODMinQuality->value());
		GOOD.set("EDist",txtGOODEDistance->value());
		GOOD.set("blockSize",txtGOODBlockSize->value());
		GOOD.set("kParam",txtGOODkParameter->value());
		GOOD.set("harris",chkGOODHarris->value());
	
	// create sub-child
	Fl_Preferences FAST = Fl_Preferences( settings, "FAST" );
		FAST.set("threshold",txtFASTThreshold->value());
		FAST.set("NonMaxSup",chkFASTNonMaxSup->value());
}

// load settings
void loadParams_Flow()
{
	int ival;
	double dval;
	char strival[100];
	char strdval[100];

	// create root setting point
	Fl_Preferences settings = Fl_Preferences( ".", "Jonathan Chandra OpenCV 2016", "OpticalFlow" );
	
	// create sub-child
	Fl_Preferences OF = Fl_Preferences( settings, "OF" );
		OF.get("winSize",ival,3); 
			sprintf(strival,"%d",ival);
			txtOFWinSize->value(strival);
		OF.get("MaxLevel",ival,5); 
			sprintf(strival,"%d",ival);
			txtOFMaxLevel->value(strival);
		OF.get("Iteration",ival,20); 
			sprintf(strival,"%d",ival);
			txtOFIteration->value(strival);
		OF.get("EPS",dval,0.3); 
			sprintf(strdval,"%lf",dval);
			txtOFEPS->value(strdval);
		OF.get("Thresholding",ival,1);
			chkOFThresholding->value(ival);
		OF.get("MinFeatures",ival,100);
			sprintf(strival,"%d",ival);
			txtOFMinFeatures->value(strival);
		OF.get("UseRANSACOutliers",ival,1);
			chkRANSACOutliers->value(ival);
		OF.get("RANSACThreshold",dval,3.0);
			sprintf(strdval,"%lf",dval);
			txtRANSACThreshold->value(strdval);
	
	settings.get("opGOOD",ival,1); opFeaturesGOOD->value(ival);
	settings.get("opFAST",ival,0); opFeaturesFAST->value(ival);
	
	// create sub-child
	Fl_Preferences GOOD = Fl_Preferences( settings, "GOOD" );
		GOOD.get("nFeatures",ival,400); 
			sprintf(strival,"%d",ival);
			txtGOODNumFeatures->value(strival);
		GOOD.get("minQ",dval, 0.01); 
			sprintf(strdval,"%lf",dval);
			txtGOODMinQuality->value(strdval);
		GOOD.get("EDist",dval, 0.01); 
			sprintf(strdval,"%lf",dval);
			txtGOODEDistance->value(strdval);
		GOOD.get("blockSize",ival,5); 
			sprintf(strival,"%d",ival);
			txtGOODBlockSize->value(strival);
		GOOD.get("kParam",dval, 0.04); 
			sprintf(strdval,"%lf",dval);
			txtGOODkParameter->value(strdval);
		GOOD.get("harris",ival,0); chkGOODHarris->value(ival);
	
	// create sub-child
	Fl_Preferences FAST = Fl_Preferences( settings, "FAST" );
		FAST.get("threshold",ival, 15);
			sprintf(strival,"%d",ival);
			txtFASTThreshold->value(strival);
		FAST.get("NonMaxSup",ival,1); chkFASTNonMaxSup->value(ival);

}



