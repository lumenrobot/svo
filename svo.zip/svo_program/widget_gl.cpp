//
/*
 *	FLTK TEMPLATE
 *	# OpenGL Widget #
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#include "widget_gl.h"
#include "main.h" // read data froms

float gl_cx, gl_cy, gl_cz;
float gl_lx, gl_ly, gl_lz;

using namespace std;

void Fl_Gl_Drawing::init_func() {
	// PUT YOUR INIT CODE HERE...
	
	// init vars
	gl_cx = 0.0f;
	gl_cy = 250.0f;
	gl_cz = 0.0f;
	gl_lx = 0.0f;
	gl_ly = 10.0f;
	gl_lz = 0.0f;
	
	// Enable blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	// call resize
	resize(x(),y(),w(),h());
	// enable me
	enable = false;
}

void Fl_Gl_Drawing::draw() {
	// DON'T EDIT -- [INITIALIZE GLEW/FUNC]
	static bool initme = false;
	if(initme == false)
	{
		// init GLEW
		GLenum err = glewInit();
		if (GLEW_OK != err)
		{
			fl_alert("Cannot initialize GLEW!");
		}
		
		// check OpenGL version!
		// and show OpenGL version
		char * gl_ver = (char*)glGetString(GL_VERSION);
		char verstr[100]; memset(verstr, 0, 100*sizeof(char));
		memcpy(verstr, gl_ver, sizeof(char)*3);
		//fl_message("This system support OpenGL version %s", verstr);
		// if version 2.1 is supported, then ok
		if(glewIsSupported("GL_VERSION_2_1") == false)
		{
			initme = true;
			enable = false;
			fl_alert("Your system doesn't support the required OpenGL !");
			return;
		}
		
		// DO NOT EDIT ANYMORE,
		// MOVED TO init_func()
		// Put your initialization code there
		//---------------------------------------------------------------------------------------
		// call the function
		init_func();
		//---------------------------------------------------------------------------------------
		// set flag to true, once
		initme = true;
	}
	
	// (Sample OpenGL Code)
	{
	//#####################################################################
	//###                                                                ##
	//###  CONTOH PENGGAMBARAN DALAM OpenGL, DENGAN SUBCLASSING BAGIAN   ##
	//###  FUNGSI draw() dari Fl_Gl_Window                               ##
	//###                                                                ##
	//#####################################################################
	
	// clear, and draw bg
	//glClearColor( R/255.0f, G/255.0f, B/255.0f, ALPHA/255.0f ); // Set background color
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clear, set bit
	
	// pemilihan view (parallel-aka-orthogonal / perspective)
	//glMatrixMode(GL_PROJECTION);	// reset projection
	//glLoadIdentity();		// tandem,reset projection
	//glOrtho(left,right,bottom,top,near,far);					// [SET AS PROJECTION, ORTHOGONAL/PARALLEL]
	//gluPerspective(fieldofviewdegrees_vertical, aspectratio_w/h, z_near, z_far);	// [SET AS PROJECTION PERSPECTIVE]
	
	// teknik pewarnaan (flat color atau gradasi)
	//glShadeModel(GL_FLAT); glShadeModel(GL_SMOOTH);
	
	// membuat tampilan wireframe
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	
	
	// Enable/Disable state eg. Lighting
	//glEnable(GL_DEPTH_TEST); // enable depth test Z -- depth buffer must requested
	//glEnable(GL_CULL_FACE); // hide surface for performance
	//glEnable( FL_LIGHTING );
	//glDisable( FL_LIGHTING );
	// check it enable/disable ?
	//if(glIsEnabled(FL_LIGHTING) == true) { ... }
	
	// Get values from states
	//void glGetBooleanv(GLenum pname, GLboolean *params);
	//void glGetDoublev(GLenum pname, GLdouble *params);
	//void glGetFloatv(GLenum pname, GLfloat *params);
	//void glGetIntegerv(GLenum pname, GLint *params);
	
	
	// translation matrix
	//glTranslatef( x, y , z );	// translate
	// rotation matrix
	//glRotatef( angle, sx, sy, sz ); // sx/sy/sz = 1.0f to rotate. set angle [WARNING: EULER ROTATION NOT QUATERNION!!]
	// scaling matrix
	//glScalef( x, y, z );
	
	// function to reset transformation (translate,rotate,scaling, etc...)
	// using identity matrix
	//glMatrixMode(GL_MODELVIEW) //select the current matrix to modelview matrix
	//glLoadIdentity(); //call to reset to identitymatrix multiplication, reset to centered at the origin of the eye coordinate system
	
	// to enable working efficiently,
	// without having to reset using glLoadIdentity and translate/transform again, use the matrix stack!
	//glPushMatrix
	//glPopMatrix
	// and don't forget to check the availability using glGet(GL_MAX_MODELVIEW_STACK_DEPTH); and glGet(GL_MAX_PROJECTION_STACK_DEPTH);
	// If you exceed the stack depth, you get a	GL_STACK_OVERFLOW error; if you try to pop a
	// matrix value off the stack when there is none, you generate a	GL_STACK_UNDERFLOW error.
	
	
	// drawing primitive type
	// TYPE {
		// @ WIREFRAME OR DOTS
		// GL_POINTS 		berupa titik
		// GL_LINES		garis antara 2 vertex (note: jika vertex ganjil maka yang terakhir di-ignore)
		// GL_LINE_STRIP	garis-garis yang terhubung (tapi tidak tertutup)
		// GL_LINE_LOOP		garis-garis yang terhubung dan TERTUTUP awal dan akhirnya akan terhubung
	
		// @ SOLID SURFACE TRIANGLES
		// GL_TRIANGLES		segitiga-segititga with filled surface (masing2 segitiga menggunakan 3 vertex)
					// NOTE: OpenGL, by default, considers polygons that have counterclockwise winding 
					//		to be front facing. [To change this behaviour, use glFrontFace(GL_CCW);]
					//	Front facing merupakan lapisan luar dari sebuah segitiga
		// GL_TRIANGLE_STRIP	segitiga-segitiga with filled surface dengan cukup menambahkan vertex > 3.
		// GL_TRIANGLE_FAN	group of segitiga dengan titik tengah pada vertex0. cukup menambahkan vertex > 3.
		
		// @ SOLID SURFACE QUADS -- Winding is CW
		// GL_QUADS		kotak dengan 4 vertice yang harus pada satu plane yang sama, tidak boleh bengkok!
		// GL_QUAD_STRIP	(mirip seperti triangle strip, namun pada quads)
		
		// @ SOLID SURFACE POLYGON
		// GL_POLYGON		mirip seperti quad, dan dpt menggantikan triangle_fan
					// [satu plane, tdk boleh bengkok atau dipelintir]
		
	// }
	//glBegin( TYPE ); // draw using vertex
	//	// set color
	//	glColor3f( R/255, G/255, B/255 );
	//	// add points
	//	glVertex3f( -0.5, 0, 0);
	//	glVertex3f( 0, 0.5, 0);
	//	glVertex3f( 0.5, 0, 0);
	//glEnd();
	
	
	// Various settings
	// # Points
		// Get supported point size range and step size
		//glGetFloatv(GL_POINT_SIZE_RANGE,<arr GLfloat>);
		//glGetFloatv(GL_POINT_SIZE_GRANULARITY,<ptr GLfloat to store>);
		// Specify the point size before the primitive is specified (call before begin-end)
			//glPointSize(GLfloat curSize);
	// # Line
		// @ WIDTH
		// Get supported line width range and step size
		//glGetFloatv(GL_LINE_WIDTH_RANGE,<arr GLfloat>);
		//glGetFloatv(GL_LINE_WIDTH_GRANULARITY,<ptr GLfloat to store>);
		//void glLineWidth(GLfloat width); // set width
		// @ TYPE DASH
		//glEnable(GL_LINE_STIPPLE); // enable stripe or dash line
		//glLineStipple(<multiply_factor>,<pattern16bit eg. 0x5555>); // set the repeat factor and pattern [call before begin-end]
	
	
	
	// draw filled rectangle (2D plane)
	//glColor4ub(R,G,B,A);
	//glRectf(x1,y1,x2,y2);
	
	
	// draw sphere using GLUT
	//glColor4ub(255, 0, 0); // set color using 0~255, RGBA
	//glutSolidSphere(10.0f, 15, 15);
	
	
	// draw camera view using look at function
	//gluLookAt( camx, camy, camz, lookx, looky, lookz, upx, upy, upz );
	
	
	//###################################################################
	}
	
	//
	// PUT YOUR DRAWING CODE AFTER THIS...
	
	if(enable == false)
	{
		// clear, and draw bg
		glClearColor( 0.f/255.0f, 0.f/255.0f, 0.f/255.0f, 255.f/255.0f ); // sets the color used for clearing the window buffer (RGBA)
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clear the buffers
		// redraw now
		glFlush();	// Render now
		swap_buffers();
	}
	
	// Drawing code...
	if(enable == true)
	{
	 
	// clear, and draw bg
	glClearColor( 0.f/255.0f, 0.f/255.0f, 0.f/255.0f, 255.f/255.0f ); // sets the color used for clearing the window buffer (RGBA)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clear the buffers
	
	// Set color shading model to ...
	glShadeModel(GL_FLAT);
	//glShadeModel(GL_SMOOTH);
	
	// Clockwise-wound polygons are front facing; this is reversed
	// because we are using triangle fans
	//glFrontFace(GL_CW);
	// default OpenGL
	glFrontFace(GL_CCW);
	
	glEnable(GL_CULL_FACE);
	//glDisable(GL_CULL_FACE);
	
	glEnable(GL_DEPTH_TEST);
	//glDisable(GL_DEPTH_TEST);
	
	// solid-view
	//	glPolygonMode(GL_FRONT,GL_FILL);
	//	glPolygonMode(GL_BACK,GL_FILL);
	// wireframe-view
	//	glPolygonMode(GL_FRONT,GL_LINE);
	//	glPolygonMode(GL_BACK,GL_LINE);
	
	//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	
	// # set camera position and orientation
	glLoadIdentity();
	gluLookAt(		// from UP to DOWN Y view, up -Z
		gl_cx,gl_cy,gl_cz,		//0.0f, 500.0f, 0.0f,
		gl_lx,gl_ly,gl_lz,		//0.0f, 0.0f, 0.0f,
		0.0f,0.0f,-1.0f			//0.0f, 0.0f, -1.0f
	);
	
	
	// # draw green grid
	//   every 10.0 (meters)
	glPushMatrix();
	{
	glColor4ub(0,255,0,127); // green color
	float grid_h = 1000.0f;
	float grid_w = 1000.0f;
		// Y is at 0.0f
		// Z as i
		// X as j
	// translate grid to center
		glTranslatef( -(grid_w/2) , 0.0f , (grid_h/2) );
	for(float i = 0.0f ; i <= grid_h ; i=i+10.0f)
	{
		for(float j = 0.0f ; j <= grid_w ; j=j+10.0f)
		{
			// distant line (infinity line)
			glBegin(GL_LINES);
				glVertex3f( j , 0.0f , 0.0f );
				glVertex3f( j , 0.0f , -grid_h );
			glEnd();
		}
		// horizon line
		glBegin(GL_LINES);
			glVertex3f( 0.0f , 0.0f , -i );
			glVertex3f( grid_w , 0.0f , -i );
		glEnd();
	}
	}
	glPopMatrix();
	
	
	// # draw KITTI pose
	glPushMatrix();
	{
		glLineWidth(5.0f);
		glBegin(GL_LINE_STRIP);
		size_t maxreal = kitti_drawpoints.size();
		if( maxreal >= 1000 ) // <--- change this later! -- use from frame count_max
 		{
			maxreal = 1000;
		}
		for(size_t i = 0 ; i < maxreal ; i++)
		{
			// set color
			glColor4f(1.0f,0.0f,0.0f,0.8f); // red line
			
			// line
			double x = kitti_drawpoints[i].x;
			double y = kitti_drawpoints[i].y;
			double z = kitti_drawpoints[i].z;
			glVertex3d(
				x, y, z
			);
			
		}
		glEnd();
	}
	glPopMatrix();
	glLineWidth(1.0f);
	
	
	// # draw ODOMETRY pose
	glPushMatrix();
	{
		glLineWidth(5.0f);
		glBegin(GL_LINE_STRIP);
		size_t maxreal = odo_drawpoints.size();
		for(size_t i = 0 ; i < maxreal ; i++)
		{
			// set color
			glColor4f(1.0f,1.0f,0.0f,0.8f); // yellow line
			
			// line
			double x = odo_drawpoints[i].x;
			double y = odo_drawpoints[i].y;
			double z = odo_drawpoints[i].z;
			glVertex3d(
				x, y, z
			);
			
		}
		glEnd();
	}
	glPopMatrix();
	glLineWidth(1.0f);
	
	
	
	
	
	
	
	
	//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	
	// redraw now
	glFlush();	// Render now
	swap_buffers();
	
	}
}

void Fl_Gl_Drawing::resize(int x, int y, int w, int h) {
	// Place your code here ...
	
	// Prevent a divide by zero
	if(h == 0)
	{
		h = 1;
	}
	
	// Set Viewport to window dimensions
	glViewport(0, 0, w, h);
	
	// Reset coordinate system
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	// Perspective Viewing Mode
	// Produce the perspective projection
	GLfloat fAspect = (GLfloat)w / (GLfloat)h;
	// (field-of-view_vertical[degrees], aspect_ratio_WperH, zNear, zFar)
	// Field of view of 45 degrees, near and far planes 1.0 and 500.0
	gluPerspective(70.0f, fAspect, 1.0, 1500.0);
	
	// Parallel Viewing Mode
	// aka Orthographic
	// Establish viewing volume (left, right, bottom, top, near, far)
	//GLfloat ukuran = 100;
	//GLfloat aspectRatio = (GLfloat)w / (GLfloat)h;
	//if (w <= h) // persegi atau bentuk kotak-tegak
	//{
		// (left,right,bottom,top,near,far)
	//	glOrtho (-ukuran, ukuran, -ukuran / aspectRatio, ukuran / aspectRatio,
	//		ukuran, -ukuran);
		// eg. 3:4
		//	-100,100, -133.33,133.33, 1,-1
	//} else {
		// (left,right,bottom,top,near,far)
	//	glOrtho (-ukuran * aspectRatio, ukuran * aspectRatio,
	//		-ukuran, ukuran, ukuran, -ukuran);
		// eg. 4:3
		//	-133.33,133.33, -100,100, 1,-1
	//}
	
	// tell OpenGL that all future transformations will affect our models (what we draw)
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// [Do not edit], return to original event
	Fl_Gl_Window::resize(x,y,w,h);
}

int Fl_Gl_Drawing::handle(int e) {
	// MOUSE HANDLING
	
	int chkmouse_x = Fl::event_x();
	int chkmouse_y = Fl::event_y();
	//int mouse_x = chkmouse_x - x();
	//int mouse_y = chkmouse_y - y();
	bool valid_mouse = false;
	
	if (
		// VALID AREA
		(chkmouse_x >= x()+1) && 
		(chkmouse_y >= y()+1) &&
		(chkmouse_x <= (x() + w() -1)) &&
		(chkmouse_y <= (y() + h() -1))
	) { valid_mouse = true; } else { valid_mouse = false; }
	
	// MOUSE MOVE
	if ( (valid_mouse==true) && ( e == FL_MOVE ) ) {
		//printf("MOVE event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		// remove comment on int mouse_x and int mouse_y to use them
		
		
		
		
		
		//---------------------------------------------------------------
	
	}
	
	// MOUSE PRESSED
	if ( (valid_mouse==true) && ( e == FL_PUSH ) ) {
		//printf("PUSH event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
		// take me as focus!
		take_focus();
		
		// responds as non-zero result, to enable FL_DRAG events
		return 1;
	}
	
	// MOUSE DRAGGED
	if ( (valid_mouse==true) && ( e == FL_DRAG ) ) {
		//printf("DRAG event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
	}
	
	// MOUSE RELEASED
	if ( (valid_mouse==true) && (e == FL_RELEASE) ) {
		//printf("RELEASE event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
	}
	// KEYBOARD HANDLING
	// ambil dari event_key()
	int key = Fl::event_key();
	
	// if shortcut (Global Hotkeys even has not focus())
	// if key is pressed
	if((e == FL_KEYDOWN))// || (e == FL_SHORTCUT))
	{
		// debug
		/*
		if(e == FL_KEYDOWN) // EVENT!!
		{
			printf("FL_KEYDOWN ; key = %c\n", key);
		}
		if(e == FL_SHORTCUT) // EVENT!!
		{
			printf("FL_SHORTCUT ; key = %c\n", key);
		}
		*/
	
		// example, key A
		/*
		if(key == 'A')
		{
			// do something
		}
		//
		// Example keyboard:
		// FL_Up	Fl_Down
		// FL_Left FL_Right
		// FL_Enter FL_Tab FL_Escape
		// Fl_BackSpace FL_Home
		// FL_Insert FL_Delete FL_Print FL_Pause
		// FL_End FL_Page_Up FL_Page_Down
		// FL_Shift_L FL_Shift_R FL_Alt_L FL_Alt_R FL_Control_L FL_Control_R
		// FL_Meta_L FL_Meta_R // Windows Key
		// FL_F + n // for function key. eg. F11 = (FL_F + 11)
		// FL_KP_Enter // keypad enter
		// FL_KP + n // keypad number
		// FL_Scroll_Lock FL_Caps_Lock FL_Num_Lock
		*/
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		
		
		redraw();
		
		//---------------------------------------------------------------
			
		// keydown via shortcut
		if((e == FL_SHORTCUT) && (key != FL_Escape))
		{
			// misc: redraw
			redraw();
			
			// responds, we take this key event
			return 1;
		}
		
	}
	
	// note: this event fired even widget has not focus
	// if key is released
	if(e == FL_KEYUP)
	{
		// debug
		/*
		printf("FL_KEYUP ; key = %c\n", key);
		*/
	
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
	}
	
	// misc: redraw this widget
	redraw();
	// RETURN FOCUS
	if(e == FL_FOCUS)
	{
		return true;
	}
	return(Fl_Gl_Window::handle(e));
}
