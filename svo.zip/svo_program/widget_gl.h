//
/*
 *	FLTK TEMPLATE
 *  # OpenGL Widget #
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#ifndef _FL_GLDRAWING
#define _FL_GLDRAWING
//----------------------------------------------------------------------

#include "fltk.h" // including all FLTK includes
#include <GL/glew.h>
#include <FL/gl.H>
#include <FL/glut.H>

using namespace std;

extern float gl_cx, gl_cy, gl_cz;
extern float gl_lx, gl_ly, gl_lz;

class Fl_Gl_Drawing : public Fl_Gl_Window {
	public:
		bool enable; // = false;
	private:
		void init_func();
	protected:
		void draw();
		void resize(int x, int y, int w, int h);
		int handle(int e);
	public:
		Fl_Gl_Drawing(int X,int Y,int W,int H,const char*L=0) : Fl_Gl_Window(X,Y,W,H,L) { enable = false; }; 
		~Fl_Gl_Drawing() {}; 
};

//----------------------------------------------------------------------
#endif
