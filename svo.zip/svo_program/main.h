//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#define SETUPFILE_KEYWORD "StereoOdometry2D3D"

// only for main.h
// include definition stored outside (called once)

#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "gui.h" // including all FLTK includes
#include "widget_cv.h"
#include "widget_gl.h"
#include "cvbasic.h"

#include "stereo.h"		// Disparity map
#include "flow.h"		// KLT Tracker, Optical Flow
#include "odometry.h" 	// Pose estimator 2D/3D


#ifndef _MYPROJECTH
#define _MYPROJECTH
//----------------------------------------------------------------------

using namespace std;
using namespace cv;

//======================================================================
// Variables
//======================================================================
extern vector<Point3d> odo_drawpoints;
extern vector<Point3d> kitti_drawpoints;


//======================================================================
// Functions
//======================================================================
extern void setup_ok();
extern void load_KITTIpose();
extern void func_cleanupExit();


//======================================================================
// GUI callbacks
//======================================================================
// frmSettings
extern void cb_frmSettings();
extern void cb_btnLoadSettings();
extern void cb_btnSaveSettings();
extern void cb_btnResetSettings();
extern void cb_frmTrajectory();
extern void cb_btnGLZoomIn();
extern void cb_btnGLZoomOut();
extern void cb_btnGLReset();
extern void cb_btnGLleft();
extern void cb_btnGLdown();
extern void cb_btnGLup();
extern void cb_btnGLright();

extern void cb_();




//----------------------------------------------------------------------
#endif

