//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//
#ifndef _ODOH
#define _ODOH

#include "main.h"

extern Mat OdoCreateQ(Mat * projMatL, Mat * projMatR);
extern void OdoFilterFeatures(Mat * disp32F, vector<Point2f> *prev_features, vector<Point2f> *features, bool *flow_pass);
extern void OdoTriangulate( Mat * ProjL , Mat * ProjR , Mat * Q , Mat * disp32F, vector<Point2f> *features2D, vector<Point3f> *outfeatures3D , int mode = 0 );
extern void OdoDrawFeatures(Mat *img, vector<Point2f> *prev_features, vector<Point2f> *features);
extern void resetParams_Odo();
extern void saveParams_Odo();
extern void loadParams_Odo();

#endif
