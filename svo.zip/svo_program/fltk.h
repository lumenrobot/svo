// INCLUDE FILES FOR FLTK

#include <FL/Fl.H>
#include <FL/x.H> // for Windows app icon
#include <FL/fl_ask.H> // messagebox
#include <FL/Fl_Preferences.H>

#include <FL/Fl_Box.H> // Fl_Box
#include <FL/fl_draw.H> // for drawing and table row
#include <FL/Fl_Table_Row.H> // Fl_Table
//#include <FL/glut.H> // glut in FLTK (don't include this here, since there are glew!)

