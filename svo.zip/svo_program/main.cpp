//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#include "main.h"

using namespace std;
using namespace cv;

// define local strucs...

// define local vars...
Mat prev_imgL;
Mat prev_imgR;
vector<Point2f> temp_prev_features; // for small OF
vector<Point2f> prev_features;
vector<Point2f> features;
Mat R_f(3,3,CV_64FC1); // double type; // the final rotation matrix
Mat t_f(3,1,CV_64FC1); // double type; // the final tranlation vectors
bool init_odo; // flag
FILE * odo_posefile; // for output pose saving

vector<Point3d> odo_drawpoints; // trajectory result 3D
vector<Point3d> kitti_drawpoints; // trajectory pose 3D (GT)

//======================================================================
// Main function

int main(int argc, char ** argv)
{
	// Create FLTK GUI
	make_window();
	
	// Set app icon (MS Windows)
	frmMain->icon( (char*) LoadIcon( fl_display, MAKEINTRESOURCE(100) ) );
	frmSetup->icon( frmMain->icon() );
	frmSettings->icon( frmMain->icon() );
	frmTrajectory->icon( frmMain->icon() );
	
	// init vars
	intrinsicL = Mat(3 ,3, CV_32FC1);
	intrinsicR = Mat(3 ,3, CV_32FC1);
	
	// Basic source selector:
	// prepare available modes
	for(int i = 0;i <= MAXSOURCEID ; i++)
	{
		if(menu_cmbSource[i].visible() == true)
		{
			// set menu
			cmbSource->value(i);
			// stop scan
			break;
		}
	}
	
	// show settings window, but disabled
	cb_btnResetSettings(); // reset at first
	frmSettings->show();
	frmSettings->deactivate();
	
	// show trjacetory window
	stageGL->enable = false;
	frmTrajectory->show();
	frmTrajectory->deactivate();
	
	// set image selection to output/result
	cmbImgResult->value( 3 );
	// show main window
	frmMain->show(argc, argv);
	
	// center, and show setup window
	center_win(frmMain);
	frmSetup->set_modal();
	frmSetup->show(argc, argv);
	center_of(frmMain,frmSetup);
	lblStatus->copy_label("");
	
	// enter FLTK loop
	int retval = Fl::run();
	
	return retval;
}


//======================================================================
// Functions


bool process_stereo(Mat *imgL, Mat *imgR) {	
	Mat undistort_imgL; Mat undistort_imgR;
	// rectify and undistort (if calibration is supplied)
	if(calibrated == true && specific_calibrated == false)
	{
		// remapping
		remap(*imgL, undistort_imgL, mapLx, mapLy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
		remap(*imgR, undistort_imgR, mapRx, mapRy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
		*imgL = undistort_imgL;
		*imgR = undistort_imgR;
	} else {
		undistort_imgL = *imgL;
		undistort_imgR = *imgR;
	}
	Mat ori_imgL; ori_imgL = (*imgL).clone();
	Mat ori_imgR; ori_imgR = (*imgR).clone();
	
	// Add your code here [Stereo Source]
	// note: 	return false to stop iteration!
	//			image showed into FLTK is on *imgL, replace it
	//------------------------------------------------------------------
	
	cout << "@Begin... " << endl;
	Mat result;
	result = (*imgL).clone();
	
	cout << "@Disparity... " << endl;
	// # Stereo disparity map for t-1
	// [POSSIBLE FOR MULTI-THREAD]
	Mat disparity_gray;
	Mat disp32F;
	if(opStereoBM->value() == true && prev_imgL.data != NULL)
	{
		disparity_gray = do_StereoBM(&prev_imgL, &prev_imgR, &disp32F);
	}
	if(opStereoSGBM->value() == true && prev_imgL.data != NULL)
	{
		disparity_gray = do_StereoSGBM(&prev_imgL, &prev_imgR, &disp32F);
	}
	if(disparity_gray.data == NULL) { disparity_gray = *imgL; }
	
	cout << "@OF... " << endl;
	// # OpticalFlow t-1,t
	// # with feature detection
	// [POSSIBLE FOR MULTI-THREAD]
	Mat imgOF;
	imgOF = do_OpticalFlow(&prev_imgL, imgL, &prev_features, &features );
	if(imgOF.data == NULL) { imgOF = *imgL; }
	//cout << features.size() << "/" << prev_features.size() << endl;
	
		// # Copy / backup features from optical flow 2D-2D
		vector<Point2f> bckp_prev_features;
		vector<Point2f> bckp_features;
			bckp_prev_features = prev_features;
			bckp_features = features;
	
	cout << "@Filter... " << endl;
	// # Features t-1,t filter /w disparity map , RANSAC , distance check
	// 		warning: remove/edit both features and prev features
	bool flow_pass;
	OdoFilterFeatures( &disp32F , &prev_features, &features , &flow_pass );
	// # Draw features on result image
	OdoDrawFeatures( &result , &prev_features, &features );
	
	cout << "@Triangulate... " << endl;
	// # Triangulate Points for t-1 features [2D->3D]
	vector<Point3f> prev3D_features;
	int mode_pose = 0;
	if(op3DProjectionMat->value() == true) { mode_pose = 0; }
	if(op3DDisparityMap->value() == true) { mode_pose = 1; }
	OdoTriangulate( &ProjectL, &ProjectR, &Qdepth , &disp32F , &prev_features, &prev3D_features, mode_pose ); // triangulate points
	
	cout << "@SolvePNP... " << endl;
	// # Pose estimator 2D/3D SolvePnP
	// solve pose problem using solvePnP()
	// 3D/2D Correspondence
	bool pose = false;
	size_t min_features = 4;
		if(strlen(txtMinKeyframeFeatures->value()) > 0)
		{
			min_features = strtol( txtMinKeyframeFeatures->value() , NULL , 10 );
			if(min_features < 4)
			{
				min_features = 4;
			}
		}
	Mat out_Rvec(3,1,CV_64FC1); // double type
	Mat out_Tvec(3,1,CV_64FC1); // double type
	if(prev3D_features.size() >= min_features && features.size() >= min_features) 
	{
		
		// estimate pose
		int spnp_flag;
		switch(cmbPNPFlag->value())
		{
			default:
			case 0:
				spnp_flag = CV_ITERATIVE;
			break;
			case 1:
				spnp_flag = CV_P3P;
			break;
			case 2:
				spnp_flag = CV_EPNP;
			break;
		}
		if(spnp_flag == CV_P3P)
		{
			// This method MUST require 4 object points and 4 image points!!
			// add your code here to acquire 4 objpts and imgpts
			// I recommend selects from 4 quadrant/parts of the image (TL TR BL BR)
			
			// for now [UNIMPLEMENTED], revert to iterative mode
			spnp_flag = CV_ITERATIVE;
			cmbPNPFlag->value(0);
		}
		solvePnP(
			prev3D_features,
			features,
			intrinsicL,
			distCoeffsL,
			out_Rvec,
			out_Tvec,
			false, // useExtrinsicGuess
			spnp_flag // ITERATIVE ; P3P ; EPNP
		);
		// set flag
		pose = true;
		
		// @ Check for min optical flow
		if(chkIgnoreSmallOF->value() == true && flow_pass == false)
		{
			// don't update this pose!
			// clear flag
			pose = false;
		}
	}
	
		// # Restore features from OF backup 2D-2D
		features = bckp_features;
		prev_features = bckp_features;
	
	cout << "@Thresholding... " << endl;
	// # Thresholding aka Keyframing
	int min_N = strtol(txtOFMinFeatures->value(),NULL,10);
	bool thresholding = chkOFThresholding->value();
	if(thresholding == true || features.size() <= 0)
	{
		if(features.size() <= (size_t)min_N)
		{
			cout << "Detecting new features..." << endl;
			
			// do re-detection of features [current frame]
			features.clear();
			Mat gray_frame;
			cvtColor(ori_imgL , gray_frame, CV_BGR2GRAY);
			detect_features(&gray_frame, &features);
			
			cout << "the size of new features is " << features.size() << endl;
		}
	} else {
		cout << "Force detection new features... " << endl;
		
		// force detection all time
		features.clear();
		Mat gray_frame;
		cvtColor(ori_imgL , gray_frame, CV_BGR2GRAY);
		detect_features(&gray_frame, &features);
	}
	
	// # Calculate global odometry values
	// first, convert 3 vector rotation into rotation matrix
	Mat out_mR(3,3,CV_64FC1);
	if(pose == true)
	{
		// modify Y and Z since in OpenCV both are inverted
		// Z follow OpenGL rule
		//out_Tvec.at<double>(2,0) = -1 * out_Tvec.at<double>(2,0);
		//out_Tvec.at<double>(3,0) = -1 * out_Tvec.at<double>(3,0);
		
		// Convert euler vector to rotation matrix
		Rodrigues( out_Rvec, out_mR ); // 3x1 to 3x3
		
		// calculate trajectory based on velocity and rotation
		if(init_odo == true)
		{
			cout << "# Odometry initialization... " << endl;
			// initialization
			t_f = out_Tvec;
			R_f = out_mR;
			
			// clear flag
			init_odo = false;
		} else {
			cout << "Tracking odometry... " << endl;
			
			// accumulate for odometry
			t_f = t_f + (R_f * out_Tvec);
			R_f = R_f * out_mR;
		}
		
		// add into pose view
		// translation data
		Point3d newT;
			newT.x = t_f.at<double>(0,0);
			newT.y = -1 * t_f.at<double>(1,0); // inverted
			newT.z = t_f.at<double>(2,0);
		odo_drawpoints.push_back(newT);
		
		// trajectory camera settings and pointer
		if(chkGLfollow->value() == true)
		{
			gl_cx = newT.x;
			gl_cz = newT.z;
			gl_lx = newT.x;
			gl_lz = newT.z;
		}
	}
	
	
	// WARNING: MOVED BELOW
	// # sets current frameL and frameR into prev_frame storages
	// # sets last features from current features
	
	//------------------------------------------------------------------
	
	// show information on screen
	char tmpstr[100];
	sprintf(tmpstr, "%d/%d", prev_features.size(), features.size());
	txtInfoNFeatures->value(tmpstr);
	// conversion from rotation matrix to rotation vector
		Mat global_rVec(3, 1, CV_64FC1);
		Rodrigues( R_f, global_rVec ); // 3x3 to 3x1
	if(pose == true)
	{
		// # Show global odometry values
		sprintf(tmpstr, "%.3lf", t_f.at<double>(0,0)); // (cartesian coord.)
		txtPosetX->value(tmpstr);
		sprintf(tmpstr, "%.3lf", t_f.at<double>(1,0) * -1); // inverted (cartesian coord.)
		txtPosetY->value(tmpstr);
		sprintf(tmpstr, "%.3lf", t_f.at<double>(2,0)); // (cartesian coord.)
		txtPosetZ->value(tmpstr);
		sprintf(tmpstr, "%.2lf", 180.0*(global_rVec.at<double>(0,0)/M_PI));
		txtPoserX->value(tmpstr);
		sprintf(tmpstr, "%.2lf", 180.0*(global_rVec.at<double>(1,0)/M_PI));
		txtPoserY->value(tmpstr);
		sprintf(tmpstr, "%.2lf", 180.0*(global_rVec.at<double>(2,0)/M_PI));
		txtPoserZ->value(tmpstr);
		
		/*
		// # Show movement/rotation per frame values
		sprintf(tmpstr, "%.3lf", out_Tvec.at<double>(0,0));
		txtPosetX->value(tmpstr);
		sprintf(tmpstr, "%.3lf", out_Tvec.at<double>(1,0));
		txtPosetY->value(tmpstr);
		sprintf(tmpstr, "%.3lf", out_Tvec.at<double>(2,0));
		txtPosetZ->value(tmpstr);
		sprintf(tmpstr, "%.2lf", 180.0*(out_Rvec.at<double>(0,0)/M_PI));
		txtPoserX->value(tmpstr);
		sprintf(tmpstr, "%.2lf", 180.0*(out_Rvec.at<double>(1,0)/M_PI));
		txtPoserY->value(tmpstr);
		sprintf(tmpstr, "%.2lf", 180.0*(out_Rvec.at<double>(2,0)/M_PI));
		txtPoserZ->value(tmpstr);
		*/
	}
	
	// # Saving pose file
	if(odo_posefile != NULL && chkSaveOdo->value() == true)
	{
		cout << "@Saving pose output..." << endl;
		char tmpstr[1000];
		sprintf(tmpstr, "%lf %lf %lf %lf %lf %lf\n",
			t_f.at<double>(0,0),
			t_f.at<double>(1,0) * -1,
			t_f.at<double>(2,0),
			180.0*(global_rVec.at<double>(0,0)/M_PI),
			180.0*(global_rVec.at<double>(1,0)/M_PI),
			180.0*(global_rVec.at<double>(2,0)/M_PI)
		);
		fwrite( tmpstr, sizeof(char), strlen(tmpstr), odo_posefile );
	}
		
	cout << "@Show image... " << endl;
	//imshow("disparity", disparity_gray);
	// show image
	switch(cmbImgResult->value())
	{
		case 0:
			// Original / Rectified frame left
			*imgL = ori_imgL;
		break;
		case 1:
			// Disparity map (left)
			*imgL = disparity_gray;
		break;
		case 2:
			// Optical flow
			*imgL = imgOF;
		break;
		
		default:
		case 3:
			// System Output Image
			*imgL = result;
		break;
	}
	
	cout << "@Final... ";
	if(chkIgnoreSmallOF->value() == false)
	{
		// {NORMALLY}
		// # sets current frameL and frameR into prev_frame storages
		prev_imgL = ori_imgL.clone();
		prev_imgR = ori_imgR.clone();
		// # sets last features from current features
		prev_features = features;
		cout << "normal ok";
	} else {
		if(flow_pass == true)
		{
			// {CONDITIONALLY WHEN OF IS PASS!}
			// # sets current frameL and frameR into prev_frame storages
			prev_imgL = ori_imgL.clone();
			prev_imgR = ori_imgR.clone();
			// # sets last features from current features
			prev_features = features;
			temp_prev_features = features;
			cout << "ok";
		} else {
			cout << "(skipped)";
			if(temp_prev_features.size() > 0)
			{
				// hold previous features
				prev_features = temp_prev_features;
			} else {
				// init
				cout << "\tinitialize hold features.. " ;
				prev_imgL = ori_imgL.clone();
				prev_imgR = ori_imgR.clone();
				temp_prev_features = features;
			}
		}
	}
	cout << endl;
	
	
	// clean up
	ori_imgL.release();
	ori_imgR.release();
	
	// redraw the trajectory
	stageGL->redraw();
	
	return true;
}

void init_ok()
{
	// when initialization / frmSetup is done
	// add your code here..
	
	// DEBUG
	//namedWindow("disparity");

	// enable form settings
	frmSettings->activate();
	
	// set flags
	init_odo = true;
	
	// select image show default from output image
	cmbImgResult->value(4);
	
	// set to null for posefile
	odo_posefile = NULL;
	
	// show trajectory map?
	// using GL window
	// enable form trajectory
	frmTrajectory->activate();
	cb_btnGLReset();
	chkGLfollow->value(true);
	stageGL->enable = true;
	
}

// User function for btnRun
void func_run( bool active )
{
	// message: this called before any iteration (start)
	//			this called after any iteration (stop)
	// Run active/not -> bool active
	
	// add your code here...
	
	if(active == true)
	{
		cout << "# Initializing odometry values... " << endl;
		
		// clear last pose
		odo_drawpoints.clear();
		
		// show KITTI pose?
		if(chkKITTI->value() == true)
		{
			load_KITTIpose();
			stageGL->redraw();
		}
		
		// save odometry pose
		if(odo_posefile != NULL)
		{
			// close it first
			fclose(odo_posefile);
			odo_posefile = NULL;
		}
		if(chkSaveOdo->value() == true)
		{
			// open pose file for saving
			odo_posefile = fopen(txtOdoPoseFile->value(), "w");
			if(odo_posefile == NULL)
			{
				fl_alert("Cannot create/save odometry pose file output!");
			}
		}
		
		// set flag
		init_odo = true;
		
		// clear features and last features
		features.clear();
		prev_features.clear();
	}
	
	if(active == false)
	{
		// save odometry pose
		if(odo_posefile != NULL && chkSaveOdo->value() == true)
		{
			// close it first
			fclose(odo_posefile);
			odo_posefile = NULL;
		}
	}
}

// User function for btnPause
void func_pause( bool active )
{
	// message: this called before any iteration (start)
	//			this called after any iteration (stop)
	// Pause active/not -> bool active
	
	// add your code here...
	
	
}

// User function for exit
void func_cleanupExit()
{
	// save odometry pose
	if(odo_posefile != NULL && chkSaveOdo->value() == true)
	{
		// close it first
		fclose(odo_posefile);
		odo_posefile = NULL;
	}
	
	
}

// Load KITTI pose from file and display it to trajectory window
void load_KITTIpose()
{
	// clear 3D point cloud
	kitti_drawpoints.clear();
	
	// read from file
	const char * filename = txtKITTIposeFile->value();
	FILE * file;
	file = fopen( filename , "r" );
	if(file == NULL)
	{
		fl_alert("Cannot read KITTI pose file!");
		return;
	}
	
	int count_tok = 0;
	char buff[2001]; memset(buff,0,2000*sizeof(char));
	while( fgets(buff, sizeof(char)*2000, file) != NULL )
	{
		//cout << buff << endl;
		// now get tokens from the string
		char * token;
		token = strtok( buff, " " );
		
		Point3d newT;
		Mat newRot = Mat_<double>(3,3);
		for(int i = 0 ; i < 12 ; i++)
		{
			if(token == NULL) { cout << "WARNING, break token?!\n"; break; }
			double value = strtod(token, NULL);
				//cout << "\t" << value << endl;
			
			// # ROTATION MATRIX
			if(count_tok == 0)
			{
				newRot.at<double>(0,0) = value;
			}
			if(count_tok == 1)
			{
				newRot.at<double>(0,1) = value;
			}
			if(count_tok == 2)
			{
				newRot.at<double>(0,2) = value;
			}
				if(count_tok == 4)
				{
					newRot.at<double>(1,0) = value;
				}
				if(count_tok == 5)
				{
					newRot.at<double>(1,1) = value;
				}
				if(count_tok == 6)
				{
					newRot.at<double>(1,2) = value;
				}
			if(count_tok == 8)
			{
				newRot.at<double>(2,0) = value;
			}
			if(count_tok == 9)
			{
				newRot.at<double>(2,1) = value;
			}
			if(count_tok == 10)
			{
				newRot.at<double>(2,2) = value;
			}
			
			// # TRANSLATION
			// conditional fetch
			if(count_tok == 3)
			{
				newT.x = value;
			}
			if(count_tok == 7)
			{
				newT.y = value;
			}
			if(count_tok == 11)
			{
				// WARNING: POSE FROM FILE IS + WHEN AWAY FROM CAMERA
				// 	    TO COMPLY WITH OpenGL Coordinates, we invert it
				newT.z = -1* value;
			}
					
			// add counter
			count_tok++;
					
			// get next one
			free(token);
			token = strtok( NULL, " " );
		}
		
		// add rotation points
			//rotMat.push_back(newRot);
			// Using OpenCV function to recover orientation pose from rotation matrix
			//Mat mtxR,mtxQ,Qx,Qy,Qz;
			//Vec3d eulerA = RQDecomp3x3( newRot , mtxR,mtxQ,Qx,Qy,Qz );
			//orientation.push_back(eulerA);
		
		// add translation points
		kitti_drawpoints.push_back(newT);
			
		// reset for next line
		count_tok = 0;
				
		free(token);
				
		//cout << endl;
	}
	
	fclose(file);
}



//======================================================================
// FLTK GUI Callbacks

// frmTrajectory



// frmSettings
void cb_frmSettings()
{
	// when closed,
	// call main form to exit too
	cb_frmMain();
}
void cb_btnLoadSettings()
{
	loadParams_Stereo();
	loadParams_Flow();
	loadParams_Odo();
}
void cb_btnSaveSettings()
{
	if(fl_choice("Save parameters?", "No", "Yes" , 0) == 0)
	{
		//fl_message("No");
		return;
	}
	saveParams_Stereo();
	saveParams_Flow();
	saveParams_Odo();
}
void cb_btnResetSettings()
{
	resetParams_Stereo();
	resetParams_Flow();
	resetParams_Odo();
}
void cb_frmTrajectory()
{
	// when closed,
	// call main form to exit too
	cb_frmMain();
}
void cb_btnGLZoomIn()
{
	// lower camera eye
	float step = 20.0f;
	if((gl_ly-step) >= 10.0f)
	{
		gl_cy = gl_cy - step;
		gl_ly = gl_ly - step;
	}
	stageGL->redraw();
}
void cb_btnGLZoomOut()
{
	// upper camera eye
	float step = 20.0f;
	gl_cy = gl_cy + step;
	gl_ly = gl_ly + step;
	stageGL->redraw();
}
void cb_btnGLReset()
{
	// disable follow
	chkGLfollow->value(false);
	// resets camera
	gl_cx = 0.0;
	gl_cy = 150.0f;
	gl_cz = 0.0f;
	gl_lx = 0.0f;
	gl_ly = 10.0f;
	gl_lz = 0.0f;
	stageGL->redraw();
}
void cb_btnGLleft()
{
	// disable follow
	chkGLfollow->value(false);
	// decrement camera x, eye/look
	float step = 5.0f;
	gl_cx -= step;
	gl_lx -= step;
	stageGL->redraw();
}
void cb_btnGLdown()
{
	// disable follow
	chkGLfollow->value(false);
	// increment camera z, eye/look
	float step = 5.0f;
	gl_cz += step;
	gl_lz += step;
	stageGL->redraw();
}
void cb_btnGLup()
{
	// disable follow
	chkGLfollow->value(false);
	// decrement camera z, eye/look
	float step = 5.0f;
	gl_cz -= step;
	gl_lz -= step;
	stageGL->redraw();
}
void cb_btnGLright()
{
	// disable follow
	chkGLfollow->value(false);
	// increment camera x, eye/look
	float step = 5.0f;
	gl_cx += step;
	gl_lx += step;
	stageGL->redraw();
}



void cb_()
{
	
}




// ===================================================================

// J U N K -- A R E A


// NOT USED
bool process(Mat *img) {	
	return false;
	/*
	Mat undistort_img;
	// undistort (if calibration is supplied)
	if(calibrated == true)
	{
		undistort(*img, undistort_img, intrinsicL, distCoeffsL);
	}
	// Add your code here [Mono Source]
	// note: return false to stop iteration!
	//			image showed into FLTK is on *img, replace it
	return true;
	*/
}


// NOT USED
void single_process(Mat *img)
{
	// Add your code here [single frame/image]
	return;
}

// NOT USED
void single_process_stereo(Mat *imgL, Mat *imgR)
{
	// Add you code here [single frame/ stereo image]
	return;
}


