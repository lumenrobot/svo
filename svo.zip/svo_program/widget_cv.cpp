//
/*
 *	FLTK TEMPLATE
 *  # OpenCV Widget #
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#include "widget_cv.h"

using namespace std;
using namespace cv;

void Fl_CV_Drawing::draw() {
	// tell base Fl_Box to draw its background & border first
	Fl_Box::draw();
	
	// (Sample Code)
	{
	//###################################################################
	//###                                                              ##
	//###  CONTOH PENGGAMBARAN DALAM FLTK, DENGAN SUBCLASSING BAGIAN   ##
	//###  FUNGSI draw() dari Fl_Widget                                ##
	//###                                                              ##
	//###################################################################
	
	// COLOR
	//fl_color(FL_BLACK || FL_BLUE || FL_RED || FL_GREEN || FL_YELLOW);
	
	// LINE
	//fl_line(x1 , y1 , x2 , y2);
	
	// SET STYLE UNTUK LINE
	//fl_line_style(FL_DASH, 3, 0); // harus setelah fl_color()!! *optional*
	//fl_line_style(0); // reset *optional*
	
	// PIE
	//fl_pie( x , y , w , h , a1 , a2 );
	
	// RECT (without fill)
	//fl_rect ( x , y , w , h )
	
	// RECT (dengan fill)
	//fl_rectf( x , y , w , h )
	
	// POINT 
	//fl_point( x , y )
	
	// CIRCLE 
	//fl_circle( x , y , r )
	
	// POLYGON
	//fl_polygon( x1 , y1 , x2 , y2 , x3 , y3 )
	
	// TEXT 
	//fl_font(FL_HELVETICA,16);
	//fl_draw( text , x , y );
	
	// ARC 
	//fl_arc( x , y , w , h , a1 , a2 )
	
	// Complex Shapes -------------------------------
	// # filled convex (cembung)
	// fl_begin_polygon();
	//	fl_vertex( x , y ); // titik sisi object
	//	fl_vertex( x , y ); // titik sisi object
	// fl_end_polygon();
	
	// # filled concave (cekung / ada coak)
	// fl_begin_complex_polygon();
	//	fl_vertex( x , y);
	//	fl_vertex( x, y );
	//	fl_gap();
	//	fl_vertex( x , y);
	// fl_end_complex_polygon();
	
	// # CLOSED outline
	// fl_begin_loop();
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	// fl_end_loop();
	
	// # unclosed outline, constatellation
	// fl_begin_line();
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	// fl_end_line();
	
	// # points drawing
	// fl_begin_points();
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	//	fl_vertex( x , y );
	// fl_end_points();
	//----------------------------------------------
	
	// Matrix Transformations
	// works with complex shapes
	// rotate and scale are only usable with +translate and -translate
	//
	// fl_push_matrix();
	//	fl_translate( x, y ); 
	//		fl_scale( 3 , 3 );
	//		fl_rotate( -90.0 );
	//	fl_translate( -x, -y );
	// fl_pop_matrix();
	
	
	// for efficient drawing, please use offscreen method
	// and put them in outside this draw() function elsewere in the program
	// and use only fl_copy_offscreen() to display it in this function draw()
	
	// > example how to build and use the offscreen
	// Fl_Offscreen buffer = fl_create_offscreen( w(), h() ); // Call this once
	// > this an example to build the objects inside offscreen, think as draw() function
	// fl_offscreen_begin( buffer );
	//	< put your ordinary drawing functions here >
	// fl_offscreen_end();
	// > finally call this function at Fl_Drawing draw() function to copy from memory and draw them in the widget
	// fl_copy_offscreen( x(), y(), w(), h() );
	
	// PIXMAP IMAGE XPM (non-transparent)
	// menggambar secara langsung, jika ingin transparan gunakan Fl_Pixmap.
	//fl_draw_pixmap( data , x , y , bg_color )
	
	//###################################################################
	}
	
	//
	// OpenCV Drawing
	if(enable == true && source != NULL)
	{
		// get width and height
		int source_w = (*source).size().width;
		int source_h = (*source).size().height;
		
		// check for resolution 640x480 ?
		if(source_w == w()-2 && source_h == h()-2 && w()==642&&h()==482)
		{
			// direct accessing
			uchar * ptrData = (*source).ptr();
	
			// draw using fltk function
			// WARNING: RGB order expected!!
			int STAGE_W = 640; int STAGE_H = 480;
			fl_draw_image(ptrData, x()+1,y()+1,STAGE_W, STAGE_H);
		} else {
			
			// process it first!
			// Zoom
			
			int out_w = w()-2; int out_h = h()-2;
			// First, resize with conditional Aspect ratio
			Size scalesz_ar_wh;
				// scaling based on h
				double ar_wh = (double)source_w / (double)source_h; 	// w:h = ?:1
				scalesz_ar_wh = Size(ceil((ar_wh*(double)out_h)),out_h);
			Size scalesz_ar_hw;
				// scaling based on w
				double ar_hw = (double)source_h / (double)source_w;	// h:w = ?:1
				scalesz_ar_hw = Size(out_w,ceil((double)out_w*ar_hw));
			Mat tempimg;
			if(source_w >= source_h)
			{
				// scale based on w
				cv::resize((*source),tempimg,scalesz_ar_hw);
			} else {
				// scale based on h
				cv::resize((*source),tempimg,scalesz_ar_wh);
			}
					
			// draw it! -- since RGB order, no problem
			fl_draw_image(tempimg.ptr(),
				x()+1+ (w()/2)-(tempimg.size().width/2) ,
				y()+1+ (h()/2)-(tempimg.size().height/2) ,
				tempimg.size().width, tempimg.size().height
			);
			
		}
		
	}
	// PUT YOUR DRAWING CODE HERE
	if(enable == true)
	{
		
		// place here ...
		
		
		
	}
}

int Fl_CV_Drawing::handle(int e) {
	// MOUSE HANDLING
	
	int chkmouse_x = Fl::event_x();
	int chkmouse_y = Fl::event_y();
	//int mouse_x = chkmouse_x - x();
	//int mouse_y = chkmouse_y - y();
	bool valid_mouse = false;
	
	if (
		// VALID AREA
		(chkmouse_x >= x()+1) && 
		(chkmouse_y >= y()+1) &&
		(chkmouse_x <= (x() + w() -1)) &&
		(chkmouse_y <= (y() + h() -1))
	) { valid_mouse = true; } else { valid_mouse = false; }
	
	// MOUSE MOVE
	if ( (valid_mouse==true) && ( e == FL_MOVE ) ) {
		//printf("MOVE event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		// remove comment on int mouse_x and int mouse_y to use them
		
		
		
		
		
		//---------------------------------------------------------------
	
	}
	
	// MOUSE PRESSED
	if ( (valid_mouse==true) && ( e == FL_PUSH ) ) {
		//printf("PUSH event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
		// when this widget clicked, take focus!
		take_focus();
		
		// responds as non-zero result, to enable FL_DRAG events
		return 1;
	}
	
	// MOUSE DRAGGED
	if ( (valid_mouse==true) && ( e == FL_DRAG ) ) {
		//printf("DRAG event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
	}
	
	// MOUSE RELEASED
	if ( (valid_mouse==true) && (e == FL_RELEASE) ) {
		//printf("RELEASE event = %d,%d\n",Fl::event_x(),Fl::event_y());
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
	}
	// KEYBOARD HANDLING
	// ambil dari event_key()
	int key = Fl::event_key();
	
	// AVAILABLE KEYS:
		// FL_Up	Fl_Down
		// FL_Left FL_Right
		// FL_Enter FL_Tab FL_Escape
		// Fl_BackSpace FL_Home
		// FL_Insert FL_Delete FL_Print FL_Pause
		// FL_End FL_Page_Up FL_Page_Down
		// FL_Shift_L FL_Shift_R FL_Alt_L FL_Alt_R FL_Control_L FL_Control_R
		// FL_Meta_L FL_Meta_R // Windows Key
		// FL_F + n // for function key. eg. F11 = (FL_F + 11)
		// FL_KP_Enter // keypad enter
		// FL_KP + n // keypad number
		// FL_Scroll_Lock FL_Caps_Lock FL_Num_Lock
	
	// if shortcut (Global Hotkeys even has not focus())
	// if key is pressed [ONLY FOCUSED]
	if(e == FL_KEYDOWN)
	{
		// example, key ENTER
		//if(key == FL_Enter)
		//{
		//	// do something
		//}
	
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
	}
	
	// if key is pressed [GLOBAL SHORTCUT]
	if((e == FL_KEYDOWN) || (e == FL_SHORTCUT))
	{
		// example, key A
		//if(key == 'A')
		//{
		//	// do something
		//}
		
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
			
		// keydown via shortcut
		if((e == FL_SHORTCUT) && (key != FL_Escape))
		{
			// misc: redraw
			redraw();
			
			// responds, we take this key event
			return 1;
		}
		
	}
	
	// note: this event fired even widget has not focus
	// if key is released
	if(e == FL_KEYUP)
	{
		// debug
		/*
		printf("FL_KEYUP ; key = %c\n", key);
		*/
	
		// put your code here ...
		//---------------------------------------------------------------
		
		
		
		
		
		//---------------------------------------------------------------
		
	}
	
	// misc: redraw this widget
	redraw();
	// return true; if focus
	if(e == FL_FOCUS)
	{
		// allow this widget to take focus
		// allow navigation using arrow and tab
		return true;
	}
	return(Fl_Box::handle(e));
}
