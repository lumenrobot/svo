//
/*
 *	FLTK - OpenCV Basic Template
 *  OpenCV basic framework
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#ifndef _BASICCVTEMPLATE
#define _BASICCVTEMPLATE
//----------------------------------------------------------------------

#include "gui.h" // including all FLTK includes
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/videoio/videoio.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/video/tracking.hpp>

using namespace std;
using namespace cv;

//======================================================================
// Global Variables [declare only]
//======================================================================
#define MAXSOURCEID 7
// FLTK Manu Items for cmbSource = menu_cmbSource
// img source index
extern int source_id; 
// for AVI and Webcam
extern VideoCapture cap, capL; 
// for STEREO AVI and Webcam
extern VideoCapture capR; 
// our real frame (color)
extern Mat frame; 
// fltk CV widget output frame
extern Mat fltk_frame; 
// FPS (defined or auto)
extern int FPS; 
// frame counter only
extern long counter; 
// seq_start
extern long start_count, start_countL, start_countR; 
// counter total frames, seq_stop
extern long total_count; 
// for single images (mono and stereo)
extern char * filename_single;
extern char ** filename_stereo;
// for sequential images, mono
extern char ** filename_seq; 
// for sequential images, stereo
extern char ** filenameL_seq; 
extern char ** filenameR_seq; 
// only for sequence images
extern char seq_filename_prefix[1024]; 
// only for sequence images
extern char seq_filename_suffix[1024]; 
// only for sequence images STEREO LR
extern char seq_filenameL_prefix[1024]; 
extern char seq_filenameR_prefix[1024]; 
// only for sequence images STEREO LR
extern char seq_filenameL_suffix[1024]; 
extern char seq_filenameR_suffix[1024]; 
// only for sequence images (number of digits)
extern int seq_digits; 
// for calibration file
extern char calibfile[1024]; 
// flag for video camera source used
extern bool videocam;
// flag for STEREO system
extern bool stereo; 
// flag for SINGLE system (mono/stereo)
extern bool single;
// flag for calibration
extern bool calibrated; 
extern bool specific_calibrated; // only get projections and Q
// calibration vars
extern Mat intrinsicL;
extern Mat intrinsicR;
extern Mat distCoeffsL;
extern Mat distCoeffsR;
extern Mat Rvect;
extern Mat Tvect;
extern Mat Emat;
extern Mat Fmat; 
// stereo system calib and rectification
extern Mat RectifyL;
extern Mat RectifyR;
extern Mat ProjectL;
extern Mat ProjectR;
extern Mat Qdepth;
extern Mat mapLx, mapLy, mapRx, mapRy; 


//======================================================================
// Functions
//======================================================================
extern bool calibration_func(const char * filename);
extern bool iter();
extern void iter_single(); // single images iteration
extern void cleanup();
extern void clear_sequenceFiles();
extern void clear_sequenceStereoFiles();
// WARNING:
//			below function is not defined on this source file!!
//			they are defined in main.cpp file!!
extern bool process(Mat *img);
extern bool process_stereo(Mat *imgL, Mat *imgR);
extern void single_process(Mat *img);
extern void single_process_stereo(Mat *imgL, Mat *imgR);
extern void init_ok();
extern void func_run( bool active );
extern void func_pause( bool active );


//======================================================================
// GUI callbacks
//======================================================================
extern void cb_frmSetup();
extern void cb_btnOK();
extern void cb_btnBlank();
extern void cb_btnLoad();
extern void cb_btnSave();
extern void timer(void * d);
extern void cb_btnRun();
extern void cb_btnPause();
extern void cb_txtFPS();
extern void cb_frmMain();




//----------------------------------------------------------------------
#endif
