//
/*
 *	FLTK - OpenCV Basic Template
 *  OpenCV basic framework
 * 	by Jonathan Chandra (c) 2016
 * 	
 */
//

#include "cvbasic.h"
#include "main.h" // some function (process) is at main source!

// DEFINITION BASIC GLOBAL VARS HERE...
// img source index
int source_id; 
// for AVI and Webcam
VideoCapture cap, capL; 
// for STEREO AVI and Webcam
VideoCapture capR; 
// our real frame (color)
Mat frame; 
// fltk CV widget output frame
Mat fltk_frame; 
// FPS (defined or auto)
int FPS; 
// frame counter only
long counter; 
// seq_start
long start_count, start_countL, start_countR; 
// counter total frames, seq_stop
long total_count; 
// for single images (mono and stereo)
char * filename_single;
char ** filename_stereo;
// for sequential images, mono
char ** filename_seq; 
// for sequential images, stereo
char ** filenameL_seq; 
char ** filenameR_seq; 
// only for sequence images
char seq_filename_prefix[1024]; 
// only for sequence images
char seq_filename_suffix[1024]; 
// only for sequence images STEREO LR
char seq_filenameL_prefix[1024]; 
char seq_filenameR_prefix[1024]; 
// only for sequence images STEREO LR
char seq_filenameL_suffix[1024]; 
char seq_filenameR_suffix[1024]; 
// only for sequence images (number of digits)
int seq_digits; 
// for calibration file
char calibfile[1024]; 
// flag for video camera source used
bool videocam;
// flag for STEREO system
bool stereo; 
// flag for SINGLE system (mono/stereo)
bool single;
// flag for calibration
bool calibrated;
bool specific_calibrated; // only get projections and Q
// calibration vars
Mat intrinsicL;
Mat intrinsicR;
Mat distCoeffsL;
Mat distCoeffsR;
Mat Rvect;
Mat Tvect;
Mat Emat;
Mat Fmat; 
// stereo system calib and rectification
Mat RectifyL;
Mat RectifyR;
Mat ProjectL;
Mat ProjectR;
Mat Qdepth;
Mat mapLx, mapLy, mapRx, mapRy; 


//======================================================================
// FLTK GUI Callbacks

void timer(void * d) {
	// check for frame interval based on FPS
	double dFPS = (double)FPS;
	long interval_ms = round((double)(1000.0 / dFPS));
	long now_ms = GetTickCount();
	static long last_ms = now_ms;
	long diff_ms = GetTickCount() - last_ms;
	if(diff_ms >= interval_ms)
	{	
		// update
		last_ms = now_ms;
		// continue as usual ...
		//
		// . . . . . . .
		
	} else {
		// skip
		Fl::repeat_timeout(0.001, timer, NULL);
		return;
	}
	// call iteration code each frame
	bool retcode;
	retcode = iter();
	// if returned code is false, the stop
	if(retcode == false)
	{
		// do not repeat with timer again
		return;
	}
	Fl::repeat_timeout( 0.001, timer, NULL ); // 1ms interval
}

void cb_btnRun() {
	
	//----------------------------------------------------- SINGLE IMAGE
	
	if(btnRun->value() == 1 && single == true)
	{
		// reset
		counter = start_count;
		
		// call single function
		iter_single();
		
		// clear
		btnRun->value(0);
	}
	
	//----------------------------------------------------- MULTI FRAMES
	
	// ENABLE
	if(btnRun->value() == 1 && single == false)
	{
		// reset
		counter = start_count;
		// Mono AVI Video only, set frame pos
		if(source_id == 2)
		{
			cap.set( CV_CAP_PROP_POS_FRAMES , 0 );
		}
		// STEREO AVI Video only
		if(source_id == 5 && stereo == true)
		{
			capL.set( CV_CAP_PROP_POS_FRAMES , 0 );
			capR.set( CV_CAP_PROP_POS_FRAMES , 0 );
		}
		
		// call user function
		func_run( true );
	
		// run the timer
		timer(NULL);
	}
	// DISABLE
	if(btnRun->value() == 0 && single == false)
	{
		// set status info
		lblStatus->copy_label("");
	
		// stop timer
		Fl::remove_timeout(timer, NULL);
		
		// call user function
		func_run( false );
	
		// clear pause
		btnPause->value(0);
	}
}

void cb_btnPause() {
	// ENABLE
	if(btnPause->value() == 1 && btnRun->value()==1)
	{
		// set information
		lblStatus->copy_label("[PAUSED]");
	
		// stop timer
		Fl::remove_timeout(timer, NULL);
		
		// call user function
		func_pause( true );
	}
	// DISABLE
	if(btnPause->value()== 0 && btnRun->value()==1)
	{
		// call user function
		func_pause( false );
		
		// call again timer
		timer(NULL);
	}
}

void cb_txtFPS() {
	if(strtol(txtFPS->value(), NULL, 10) > 0)
	{
		FPS = strtol(txtFPS->value(), NULL, 10);
	}
}

void cb_frmMain() {
	// when user hit close or esc key
	cleanup();
	exit(0);
}

void cb_frmSetup() {
	// when user hit escape or closes the window
	exit(0);
}

void cb_btnOK() {
	
	// Check and Open VideoCapture
	source_id = cmbSource->value();
	if(strlen(txtParamA->value()) <= 0)
	{
		fl_alert("Cannot continue!\nPlease fill parameter A!");
		return;
	}
	if((	source_id == 1 || 
			source_id == 3 ||
			source_id == 4 ||
			source_id == 5 ||
			source_id == 7
		) 
		&& strlen(txtParamB->value())<=0 )
	{
		fl_alert("Cannot continue!\nPlease specify parameter B too!");
		return;
	}
	
	//------------------------------------------------------------------
	
	// # WEBCAM
	// initialization based on type
	if(source_id == 0)
	{
		// # Multiple frames image
		single = false;
		// # Set STEREO flag
		stereo = false;
		// # Set video/cam flag
		videocam = true;
	
		// # INITIALIZE WEBCAM
		int id = strtol(txtParamA->value(), NULL, 10);
		cap.open(id);
		if(cap.isOpened() == false)
		{
			// error
			fl_alert("Cannot open USB Camera/Webcam!");
			return;
		}
		
		// # Set camera properties -- if supplied
		int set_w = strtol(txtUSBCw->value(),NULL,10);
		int set_h = strtol(txtUSBCh->value(),NULL,10);
		if(strlen(txtUSBCw->value()) > 0 && strlen(txtUSBCh->value()) > 0)
		{
			// # Set camera format mode -- if supplied
			// must before setting resolution!
			// if no resolution specified, then it's a waste!
			if(strlen(txtUSBCFOURCC->value()) == 4)
			{
				char fourcc[5];
				fourcc[0] = txtUSBCFOURCC->value()[0];
				fourcc[1] = txtUSBCFOURCC->value()[1];
				fourcc[2] = txtUSBCFOURCC->value()[2];
				fourcc[3] = txtUSBCFOURCC->value()[3];
				cap.set(CV_CAP_PROP_FOURCC, CV_FOURCC( fourcc[0], fourcc[1], fourcc[2], fourcc[3] ));
			}
			
			// setting resolution
			cap.set(CV_CAP_PROP_FRAME_WIDTH, set_w);
			cap.set(CV_CAP_PROP_FRAME_HEIGHT, set_h);
		}
		
		// # Get properties
		int w = cap.get(CV_CAP_PROP_FRAME_WIDTH);
		int h = cap.get(CV_CAP_PROP_FRAME_HEIGHT);
		// second, FPS
		FPS = cap.get(CV_CAP_PROP_FPS);
		if(FPS <= 0)
		{
			// assumpsion
			// get as fast as possible then :D
			FPS = 30;	
		}
		start_count = 0;
		total_count = 0; // streaming, so no limit
		
		// check requested size
		if(strlen(txtUSBCw->value()) > 0 && strlen(txtUSBCh->value()) > 0)
		{
			if(w != set_w || h != set_h)
			{
				fl_alert("Camera frame size cannot be sized by your request!");
				cap.release();
				return;
			}
		}
		
		// disabled
		// check for resolution must be 640x480
		if(w!=640 || h!=480)
		{
			//cap.release();
			//fl_alert("Image resolution is not 640x480!\nCannot continue!");
			//return;
		}
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// must false, MONO
				// check for stereo flag in calibration file
				bool stereo_calib = true;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == true)
				{
					cap.release();
					fl_alert("False calibration file! NOT compatible to SINGLE system!");
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					cap.release();
					fl_alert("Cannot do calibration!");
					return;
				}
			} else {
				cap.release();
				fl_alert("Cannot read calibration file!");
				return;
			}
		}
	}
	
	// # SEQUENCE
	// initialization based on type
	if(source_id == 1)
	{
		// # Multiple frames image
		single = false;
		// # Set STEREO flag
		stereo = false;
		// # Clear video/cam flag
		videocam = false;
		
		// # Image Sequence
		// Test by opening the image and close it
		const char * filename_start = txtParamA->value();
		const char * filename_stop = txtParamB->value();
		Mat A = imread(filename_start);
		Mat B = imread(filename_stop);
		if(A.data == NULL || B.data == NULL)
		{
			// error
			fl_alert("Cannot read image sequence!");
			return;	
		}
		
		// Get properties
		// get sequence length -> this relate to frame count total
		int start; char strstart[100]; memset(strstart, 0, 100*sizeof(char));
		int end; char strend[100]; memset(strend, 0, 100*sizeof(char));
		int digit_len_start; int digit_len_stop;
		// @ START SEQUENCE DETECT
		int j;
		int idx_num_b;
		int idx_num_e;
		unsigned int len;
		char prefix_A_start[100]; char prefix_A_end[100];
		char prefix_B_start[100]; char prefix_B_end[100];
		j = 0;
		idx_num_b = -1;
		idx_num_e = -1;
		memset(prefix_A_start,0,100*sizeof(char));
		memset(prefix_A_end,0,100*sizeof(char));
		for(unsigned int i = 0 ; i < strlen(filename_start) ; i++)
		{
			int chk = filename_start[i];
			if(((chk - 57) <= 0) && ((chk - 57)>=-9))
			{
				// capture begining index for numbering pattern
				if(idx_num_b == -1)
				{
					idx_num_b = i;
				}
				
				// store char by char to number string
				strstart[j] = chk;
				j++;
			} else {
				// capture ending index for numbering pattern
				if(idx_num_b >= 0) // already found
				{
					if(idx_num_e == -1)
					{
						idx_num_e = i-1;
					}
				}	
			}
		}
		if(idx_num_b == -1 || idx_num_e == -1)
		{
			fl_alert("Sequence number is not found! Failed.");
			return;
		}
		start = strtol(strstart, NULL, 10);
		memcpy(prefix_A_start,filename_start+0,idx_num_b);
		len = strlen(filename_start);
		memcpy(prefix_A_end,filename_start+idx_num_e+1,(len-idx_num_e+1));
		digit_len_start = idx_num_e - idx_num_b + 1;
		// @ END SEQUENCE DETECT
		j = 0;
		idx_num_b = -1;
		idx_num_e = -1;
		memset(prefix_B_start,0,100*sizeof(char));
		memset(prefix_B_end,0,100*sizeof(char));
		for(unsigned int i = 0 ; i < strlen(filename_stop) ; i++)
		{
			int chk = filename_stop[i];
			if(((chk - 57) <= 0) && ((chk - 57)>=-9))
			{
				// capture begining index for numbering pattern
				if(idx_num_b == -1)
				{
					idx_num_b = i;
				}
			
				// store char by char to number string
				strend[j] = chk;
				j++;
			} else {
				// capture ending index for numbering pattern
				if(idx_num_b >= 0) // already found
				{
					if(idx_num_e == -1)
					{
						idx_num_e = i-1;
					}
				}	
			}
		}
		if(idx_num_b == -1 || idx_num_e == -1)
		{
			fl_alert("Sequence number is not found! Failed.");
			return;
		}
		end = strtol(strend, NULL, 10);
		memcpy(prefix_B_start,filename_stop+0,idx_num_b);
		len = strlen(filename_stop);
		memcpy(prefix_B_end,filename_stop+idx_num_e+1,(len-idx_num_e+1));
		digit_len_stop = idx_num_e - idx_num_b + 1;
		//fl_message("[START]\n"
		//	"\'%s\' ... \'%s\'\n\n"
		//	"[STOP]\n"
		//	"\'%s\' ... \'%s\'\n",
		//		prefix_A_start, prefix_A_end,
		//		prefix_B_start, prefix_B_end	
		//);
		//fl_message("Detected %s to %s, total %ld", strstart, strend, total_count);
		// get image resolution
		int w = (A.cols + B.cols)/2;
		int h = (A.rows + B.rows)/2;
		
		// close it
		A.release();
		B.release();
		
		// set default FPS to 10
		FPS = 10; // you can change this later, no problem
		// set sequence start
		start_count = start;
		// set total count
		total_count = end - start +1; // +1 since the 'start' is counted too
		// check for consistency prefix and suffix for START and STOP filenames
		if(	strcmp(prefix_A_start, prefix_B_start)!=0 ||
			strcmp(prefix_A_end, prefix_B_end)!=0 ||
			digit_len_start != digit_len_stop
		) {
			// difference found!, error
			fl_alert("Sequence filename is NOT consistent!, try again!");
			return;
		}
		sprintf(seq_filename_prefix, "%s", prefix_A_start);
		sprintf(seq_filename_suffix, "%s", prefix_A_end);
		seq_digits = digit_len_start;
		//fl_message("Sequence digits is %d", seq_digits);
		//fl_message("\'%s\' ... \'%s\'", seq_filename_prefix , seq_filename_suffix);
		
		// total frame must positive!
		if(total_count <= 1)
		{
			fl_alert("Sequence number is not right!!");
			return;
		}
		
		// disabled
		// check for resolution must be 640x480
		if(w!=640 || h!=480)
		{
			//fl_alert("Image resolution is not 640x480!");
			//return;
		}
		
		// prepare master array filename
		filename_seq = (char**) calloc( total_count , sizeof(char*) );
		// set filename each...
		for(long i = 0 ; i < total_count ; i++)
		{
			// allocate
			filename_seq[i] = (char*) calloc(1024, sizeof(char));
			// set value
			char seq_numstr[100];
				char formatstr[10];
				sprintf(formatstr, "%%0%dd", seq_digits);
			sprintf(seq_numstr,formatstr, (i+start_count));
			sprintf(filename_seq[i], "%s%s%s", seq_filename_prefix, seq_numstr, seq_filename_suffix);
		}
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// must false, MONO
				// check for stereo flag in calibration file
				bool stereo_calib = true;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == true)
				{
					fl_alert("False calibration file! NOT compatible to SINGLE system!");
					clear_sequenceFiles();
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					fl_alert("Cannot do calibration!");
					clear_sequenceFiles();
					return;
				}
			} else {
				//cap.release();
				fl_alert("Cannot read calibration file!");
				clear_sequenceFiles();
				return;
			}
		}
		
	}
	
	// # AVI FILE
	// initialization based on type
	if(source_id == 2)
	{
		// # Multiple frames image
		single = false;
		// # Set STEREO flag
		stereo = false;
		// # Set video/cam flag
		videocam = true;
		
		// # INITIALIZE AVI FILE
		const char * filename = txtParamA->value();
		cap.open(filename);
		if(cap.isOpened() == false)
		{
			// error
			fl_alert("Cannot open AVI Video!");
			return;	
		}
		
		// # GET PROPERTIES
		// first, size
		int w = cap.get(CV_CAP_PROP_FRAME_WIDTH);
		int h = cap.get(CV_CAP_PROP_FRAME_HEIGHT);
		// second, FPS
		FPS = cap.get(CV_CAP_PROP_FPS);
		// set counter
		start_count = 0;
		// third, get frame count
		total_count = cap.get( CV_CAP_PROP_FRAME_COUNT );
		
		// disabled
		// check for resolution must be 640x480
		if(w!=640 || h!=480)
		{
			//cap.release();
			//fl_alert("Image resolution is not 640x480!\nCannot continue!");
			//return;
		}
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// must false, MONO
				// check for stereo flag in calibration file
				bool stereo_calib = true;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == true)
				{
					cap.release();
					fl_alert("False calibration file! NOT compatible to SINGLE system!");
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					cap.release();
					fl_alert("Cannot do calibration!");
					return;
				}
			} else {
				cap.release();
				fl_alert("Cannot read calibration file!");
				return;
			}
		}
	}
	
	// # STEREO WEBCAM
	// initialization based on type
	if(source_id == 3)
	{
		// # Multiple frames image
		single = false;
		// # Set STEREO flag
		stereo = true;
		// # Set video/cam flag
		videocam = true;
		
		// # INITIALIZE WEBCAM
		int idL = strtol(txtParamA->value(), NULL, 10);
		capL.open(idL);
		if(capL.isOpened() == false)
		{
			// error
			fl_alert("Cannot open USB Left Camera/Webcam!");
			return;
		}
		int idR = strtol(txtParamB->value(), NULL, 10);
		capR.open(idR);
		if(capR.isOpened() == false)
		{
			// error
			capL.release(); // release left camera
			fl_alert("Cannot open USB Right Camera/Webcam!");
			return;
		}
		
		// # Set camera properties -- if supplied
		int set_w = strtol(txtUSBCw->value(),NULL,10);
		int set_h = strtol(txtUSBCh->value(),NULL,10);
		if(strlen(txtUSBCw->value()) > 0 && strlen(txtUSBCh->value()) > 0)
		{
			// # Set camera format mode -- if supplied
			// must before setting resolution!
			// if no resolution specified, then it's a waste!
			if(strlen(txtUSBCFOURCC->value()) == 4)
			{
				char fourcc[5];
				fourcc[0] = txtUSBCFOURCC->value()[0];
				fourcc[1] = txtUSBCFOURCC->value()[1];
				fourcc[2] = txtUSBCFOURCC->value()[2];
				fourcc[3] = txtUSBCFOURCC->value()[3];
				capL.set(CV_CAP_PROP_FOURCC, CV_FOURCC( fourcc[0], fourcc[1], fourcc[2], fourcc[3] ));
				capR.set(CV_CAP_PROP_FOURCC, CV_FOURCC( fourcc[0], fourcc[1], fourcc[2], fourcc[3] ));
			}
			
			// setting resolution
			capL.set(CV_CAP_PROP_FRAME_WIDTH, set_w);
			capL.set(CV_CAP_PROP_FRAME_HEIGHT, set_h);
			capR.set(CV_CAP_PROP_FRAME_WIDTH, set_w);
			capR.set(CV_CAP_PROP_FRAME_HEIGHT, set_h);
		}
		
		// # Get properties
		int wL = capL.get(CV_CAP_PROP_FRAME_WIDTH);
		int hL = capL.get(CV_CAP_PROP_FRAME_HEIGHT);
		int wR = capR.get(CV_CAP_PROP_FRAME_WIDTH);
		int hR = capR.get(CV_CAP_PROP_FRAME_HEIGHT);
		// second, FPS
		int FPS_L = capL.get(CV_CAP_PROP_FPS);
		int FPS_R = capR.get(CV_CAP_PROP_FPS);
		if(FPS_L != FPS_R)
		{
			capL.release();
			capR.release();
			fl_alert("Inconsistent in webcam/camera FPS framerate between left and right");
			return;
		}
		FPS = FPS_L;
		if(FPS <= 0)
		{
			// assumpsion
			// get as fast as possible then :D
			FPS = 30;	
		}
		start_count = 0;
		total_count = 0; // streaming, so no limit
		
		// check for camera same resolution
		if(wL != wR || hL != hR)
		{
			capL.release();
			capR.release();
			fl_alert("Camera is not having the same resolution!");
			return;
		}
		
		// check for requested camera frame size
		if(strlen(txtUSBCw->value()) > 0 && strlen(txtUSBCh->value()) > 0)
		{
			if( (wL != set_w || hL != set_h) || (wR != set_w || hR != set_h) )
			{
				fl_alert("Camera frame size cannot be sized by your request!");
				capL.release();
				capR.release();
				return;
			}
		}
		
		// disabled
		// check for resolution must be 640x480
		if(wL!=640 || hL!=480)
		{
			//capL.release();
			//capR.release();
			//fl_alert("Image resolution is not 640x480!\nCannot continue!");
			//return;
		}
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// check for stereo flag in calibration file
				bool stereo_calib = false;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == false)
				{
					capL.release();
					capR.release();
					fl_alert("False calibration file! NOT compatible to STEREO system!");
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					capL.release();
					capR.release();
					fl_alert("Cannot do calibration!");
					return;
				}
			} else {
				capL.release();
				capR.release();
				fl_alert("Cannot read calibration file!");
				return;
			}
		}
	}
	
	// # STEREO SEQUENCE
	// initialization based on type
	if(source_id == 4)
	{
		// # Multiple frames image
		single = false;
		// # Set STEREO flag
		stereo = true;
		// # Set video/cam flag
		videocam = false;
	
		// # Image Sequence
		// Test by opening the image and close it
		const char * paramA = txtParamA->value();
			// @LEFT
			// find separator ';' semicolon
			int idx_separatorL = 0;
			bool separatorL_found = false;
			for(unsigned int i = 0 ; i < strlen(paramA) ; i++)
			{
				if(paramA[i] == ';')
				{
					idx_separatorL = i;
					separatorL_found = true;
					break;
				}
			}
			if(separatorL_found == false)
			{
				fl_alert("Error, cannot differentiate LEFT start/stop sequence!");
				return;
			}
		unsigned int lenL = strlen(paramA);
		char * filenameL_start = (char*) calloc(lenL,sizeof(char));
			memcpy(filenameL_start,paramA+0,idx_separatorL*sizeof(char));
		char * filenameL_stop = (char*) calloc(lenL,sizeof(char));
			memcpy(filenameL_stop,paramA+idx_separatorL+1,(lenL-idx_separatorL)*sizeof(char));
		// debug
		//fl_message("{LEFT} \'%s\' to \'%s\'", filenameL_start, filenameL_stop);
		Mat AL = imread(filenameL_start);
		Mat BL = imread(filenameL_stop);
		if(AL.data == NULL || BL.data == NULL)
		{
			// error
			fl_alert("Cannot read LEFT image sequence!");
			return;	
		}
		const char * paramB = txtParamB->value();
			// @RIGHT
			// find separator ';' semicolon
			int idx_separatorR = 0;
			bool separatorR_found = false;
			for(unsigned int i = 0 ; i < strlen(paramB) ; i++)
			{
				if(paramB[i] == ';')
				{
					idx_separatorR = i;
					separatorR_found = true;
					break;
				}
			}
			if(separatorR_found == false)
			{
				fl_alert("Error, cannot differentiate RIGHT start/stop sequence!");
				return;
			}
		unsigned int lenR = strlen(paramB);
		char * filenameR_start = (char*) calloc(lenR,sizeof(char));
			memcpy(filenameR_start,paramB+0,idx_separatorR*sizeof(char));
		char * filenameR_stop = (char*) calloc(lenR,sizeof(char));
			memcpy(filenameR_stop,paramB+idx_separatorR+1,(lenR-idx_separatorR)*sizeof(char));
		// debug
		//fl_message("{RIGHT} \'%s\' to \'%s\'", filenameR_start, filenameR_stop);
		Mat AR = imread(filenameR_start);
		Mat BR = imread(filenameR_stop);
		if(AR.data == NULL || BR.data == NULL)
		{
			// error
			fl_alert("Cannot read RIGHT image sequence!");
			return;	
		}
		
			// OK
			// debug
			//fl_message("LEFT file \'%s\' ... \'%s\'", filenameL_start, filenameL_stop);
			//fl_message("RIGHT file \'%s\' ... \'%s\'", filenameR_start, filenameR_stop);
		
		// Get properties
		// get sequence length -> this relate to frame count total
		char prefix_AL_start[100]; char prefix_AL_end[100];
		char prefix_BL_start[100]; char prefix_BL_end[100];
			memset(prefix_AL_start,0,100*sizeof(char));
			memset(prefix_AL_end,0,100*sizeof(char));
		char prefix_AR_start[100]; char prefix_AR_end[100];
		char prefix_BR_start[100]; char prefix_BR_end[100];
			memset(prefix_AR_start,0,100*sizeof(char));
			memset(prefix_AR_end,0,100*sizeof(char));
		int startL; char strstartL[100]; memset(strstartL, 0, 100*sizeof(char));
		int endL; char strendL[100]; memset(strendL, 0, 100*sizeof(char));
		int startR; char strstartR[100]; memset(strstartR, 0, 100*sizeof(char));
		int endR; char strendR[100]; memset(strendR, 0, 100*sizeof(char));
		int digit_len_startL; int digit_len_stopL;
		int digit_len_startR; int digit_len_stopR;
		// @LEFT
		{
			// @ START SEQUENCE DETECT
			int j;
			int idx_num_b;
			int idx_num_e;
			unsigned int len;
			j = 0;
			idx_num_b = -1;
			idx_num_e = -1;
			for(unsigned int i = 0 ; i < strlen(filenameL_start) ; i++)
			{
				int chk = filenameL_start[i];
				if(((chk - 57) <= 0) && ((chk - 57)>=-9))
				{
					// capture begining index for numbering pattern
					if(idx_num_b == -1)
					{
						idx_num_b = i;
					}
					
					// store char by char to number string
					strstartL[j] = chk;
					j++;
				} else {
					// capture ending index for numbering pattern
					if(idx_num_b >= 0) // already found
					{
						if(idx_num_e == -1)
						{
							idx_num_e = i-1;
						}
					}	
				}
			}
			if(idx_num_b == -1 || idx_num_e == -1)
			{
				fl_alert("LEFT start sequence number is not found! Failed.");
				return;
			}
			startL = strtol(strstartL, NULL, 10);
			memcpy(prefix_AL_start,filenameL_start+0,idx_num_b);
			len = strlen(filenameL_start);
			memcpy(prefix_AL_end,filenameL_start+idx_num_e+1,(len-idx_num_e+1));
			digit_len_startL = idx_num_e - idx_num_b + 1;
			// @ END SEQUENCE DETECT
			j = 0;
			idx_num_b = -1;
			idx_num_e = -1;
			memset(prefix_BL_start,0,100*sizeof(char));
			memset(prefix_BL_end,0,100*sizeof(char));
			for(unsigned int i = 0 ; i < strlen(filenameL_stop) ; i++)
			{
				int chk = filenameL_stop[i];
				if(((chk - 57) <= 0) && ((chk - 57)>=-9))
				{
					// capture begining index for numbering pattern
					if(idx_num_b == -1)
					{
						idx_num_b = i;
					}
				
					// store char by char to number string
					strendL[j] = chk;
					j++;
				} else {
					// capture ending index for numbering pattern
					if(idx_num_b >= 0) // already found
					{
						if(idx_num_e == -1)
						{
							idx_num_e = i-1;
						}
					}	
				}
			}
			if(idx_num_b == -1 || idx_num_e == -1)
			{
				fl_alert("LEFT stop sequence number is not found! Failed.");
				return;
			}
			endL = strtol(strendL, NULL, 10);
			memcpy(prefix_BL_start,filenameL_stop+0,idx_num_b);
			len = strlen(filenameL_stop);
			memcpy(prefix_BL_end,filenameL_stop+idx_num_e+1,(len-idx_num_e+1));
			digit_len_stopL = idx_num_e - idx_num_b + 1;
		}
		// @RIGHT
		{
			// @ START SEQUENCE DETECT
			int j;
			int idx_num_b;
			int idx_num_e;
			unsigned int len;
			j = 0;
			idx_num_b = -1;
			idx_num_e = -1;
			for(unsigned int i = 0 ; i < strlen(filenameR_start) ; i++)
			{
				int chk = filenameR_start[i];
				if(((chk - 57) <= 0) && ((chk - 57)>=-9))
				{
					// capture begining index for numbering pattern
					if(idx_num_b == -1)
					{
						idx_num_b = i;
					}
					
					// store char by char to number string
					strstartR[j] = chk;
					j++;
				} else {
					// capture ending index for numbering pattern
					if(idx_num_b >= 0) // already found
					{
						if(idx_num_e == -1)
						{
							idx_num_e = i-1;
						}
					}	
				}
			}
			if(idx_num_b == -1 || idx_num_e == -1)
			{
				fl_alert("RIGHT start sequence number is not found! Failed.");
				return;
			}
			startR = strtol(strstartR, NULL, 10);
			memcpy(prefix_AR_start,filenameR_start+0,idx_num_b);
			len = strlen(filenameR_start);
			memcpy(prefix_AR_end,filenameR_start+idx_num_e+1,(len-idx_num_e+1));
			digit_len_startR = idx_num_e - idx_num_b + 1;
			// @ END SEQUENCE DETECT
			j = 0;
			idx_num_b = -1;
			idx_num_e = -1;
			memset(prefix_BR_start,0,100*sizeof(char));
			memset(prefix_BR_end,0,100*sizeof(char));
			for(unsigned int i = 0 ; i < strlen(filenameR_stop) ; i++)
			{
				int chk = filenameR_stop[i];
				if(((chk - 57) <= 0) && ((chk - 57)>=-9))
				{
					// capture begining index for numbering pattern
					if(idx_num_b == -1)
					{
						idx_num_b = i;
					}
				
					// store char by char to number string
					strendR[j] = chk;
					j++;
				} else {
					// capture ending index for numbering pattern
					if(idx_num_b >= 0) // already found
					{
						if(idx_num_e == -1)
						{
							idx_num_e = i-1;
						}
					}	
				}
			}
			if(idx_num_b == -1 || idx_num_e == -1)
			{
				fl_alert("RIGHT stop sequence number is not found! Failed.");
				return;
			}
			endR = strtol(strendR, NULL, 10);
			memcpy(prefix_BR_start,filenameR_stop+0,idx_num_b);
			len = strlen(filenameR_stop);
			memcpy(prefix_BR_end,filenameR_stop+idx_num_e+1,(len-idx_num_e+1));
			digit_len_stopR = idx_num_e - idx_num_b + 1;
		}		
		
			// debug
			//fl_message("LEFT start/stop = %s/%s", strstartL,strendL);
			//fl_message("RIGHT start/top = %s/%s", strstartR,strendR);
		
		// get image resolution
		int wL = (AL.cols + BL.cols)/2;
		int hL = (AL.rows + BL.rows)/2;
		int wR = (AR.cols + BR.cols)/2;
		int hR = (AR.rows + BR.rows)/2;
		
		// close it
		AL.release();
		BL.release();
		AR.release();
		BR.release();
		
		// check digits length consistency START/STOP for LEFT and RIGHT
		if(digit_len_startL != digit_len_startR ||
			digit_len_stopL != digit_len_stopR
		) {
			// error
			fl_alert("Digits is not consitent between START/STOP left and right!");
			return;
		}
		
		// length for start and stop for LEFT and RIGHT must same value!
		if(
			(endL-startL) != (endR-startR) 
		) {
			// error
			fl_alert("Start and Stop length sequence for LEFT and RIGHT is not consistent!!");
			return;
		}
		
		// check for image size consistency for LEFT and RIGHT
		if(wL != wR || hL != hR)
		{
			// eror
			fl_alert("Image size is not consistenct for LEFT and RIGHT!");
			return;
		}
		
		// set default FPS to 10
		FPS = 10; // you can change this later, no problem
		// set start counter
		start_countL = startL;
		start_countR = startR;
		// set total count
		total_count = endL - startL +1; // +1 since the 'start' is counted too
		// check for consistency prefix and suffix for START and STOP filenames
		if(	strcmp(prefix_AL_start, prefix_BL_start)!=0 ||
			strcmp(prefix_AL_end, prefix_BL_end)!=0 ||
			strcmp(prefix_AR_start, prefix_BR_start)!=0 ||
			strcmp(prefix_AR_end, prefix_BR_end)!=0 ||
			digit_len_startL != digit_len_stopL ||
			digit_len_startR != digit_len_stopR
		) {
			// difference found!, error
			fl_alert("Sequence filename is NOT consistent!, try again!");
			return;
		}
		sprintf(seq_filenameL_prefix, "%s", prefix_AL_start);
		sprintf(seq_filenameL_suffix, "%s", prefix_AL_end);
		sprintf(seq_filenameR_prefix, "%s", prefix_AR_start);
		sprintf(seq_filenameR_suffix, "%s", prefix_AR_end);
		seq_digits = digit_len_startL;
		//fl_message("Sequence digits is %d", seq_digits);
		//fl_message("\'%s\' ... \'%s\'", seq_filename_prefix , seq_filename_suffix);
		
		// total frame must positive!
		if(total_count <= 1)
		{
			fl_alert("Sequence number is not right!!");
			return;
		}
		
		// disabled	
		// check for resolution must be 640x480
		if(wL!=640 || hL!=480)
		{
			//fl_alert("Image resolution is not 640x480!\nCannot continue!");
			//return;
		}
		
		// prepare master array filename
		filenameL_seq = (char**) calloc( total_count , sizeof(char*) );
		filenameR_seq = (char**) calloc( total_count , sizeof(char*) );
		// set filename each...
		for(long i = 0 ; i < total_count ; i++)
		{
			// allocate
			filenameL_seq[i] = (char*) calloc(1024, sizeof(char));
			filenameR_seq[i] = (char*) calloc(1024, sizeof(char));
			// set value
			char seq_numstr[100];
				char formatstr[10];
				sprintf(formatstr, "%%0%dd", seq_digits);
			sprintf(seq_numstr,formatstr, (i+start_countL));
			sprintf(filenameL_seq[i], "%s%s%s", seq_filenameL_prefix, seq_numstr, seq_filenameL_suffix);
			sprintf(seq_numstr,formatstr, (i+start_countR));
			sprintf(filenameR_seq[i], "%s%s%s", seq_filenameR_prefix, seq_numstr, seq_filenameR_suffix);
			
			// debug
			//cout << "L = " << filenameL_seq[i] << endl;
			//cout << "R = " << filenameR_seq[i] << endl;
			//cout << endl;
		}
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// check for stereo flag in calibration file
				bool stereo_calib = false;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == false)
				{
					fl_alert("False calibration file! NOT compatible to STEREO system!");
					clear_sequenceStereoFiles();
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					fl_alert("Cannot do calibration!");
					clear_sequenceStereoFiles();
					return;
				}
			} else {
				fl_alert("Cannot read calibration file!");
				clear_sequenceStereoFiles();
				return;
			}
		}
		
	}
	
	// # STEREO AVI FILE
	// initialization based on type
	if(source_id == 5)
	{
		// # Multiple frames image
		single = false;
		// # Set STEREO flag
		stereo = true;
		// # Set video/cam flag
		videocam = true;
		
		// # INITIALIZE AVI FILE
		const char * filenameA = txtParamA->value();
		capL.open(filenameA);
		if(capL.isOpened() == false)
		{
			// error
			fl_alert("Cannot open Left AVI Video!");
			return;	
		}
		const char * filenameB = txtParamB->value();
		capR.open(filenameB);
		if(capR.isOpened() == false)
		{
			// error
			capL.release();
			fl_alert("Cannot open Right AVI Video!");
			return;	
		}
		
		// # GET PROPERTIES
		// first, size
		int wL = capL.get(CV_CAP_PROP_FRAME_WIDTH);
		int hL = capL.get(CV_CAP_PROP_FRAME_HEIGHT);
		int wR = capR.get(CV_CAP_PROP_FRAME_WIDTH);
		int hR = capR.get(CV_CAP_PROP_FRAME_HEIGHT);
		// second, FPS
		FPS = cap.get(CV_CAP_PROP_FPS);
		// third, get frame count
		long total_countL = capL.get( CV_CAP_PROP_FRAME_COUNT );
		long total_countR = capR.get( CV_CAP_PROP_FRAME_COUNT );
		
		// check for frame count
		if(total_countL != total_countR)
		{
			capL.release();
			capR.release();
			fl_alert("Inconsistent video file length!");
			return;
		}
		start_count = 0;
		total_count = total_countL;
		
		// check size consistency between LEFT and RIGHT
		if(wL != wR || hL != hR)
		{
			capL.release();
			capR.release();
			fl_alert("Image resolution between left and right is not same size!");
			return;
		}
		
		// disabled
		// check for resolution must be 640x480
		if(wL!=640 || hL!=480)
		{
			//capL.release();
			//capR.release();
			//fl_alert("Image resolution is not 640x480!\nCannot continue!");
			//return;
		}
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// check for stereo flag in calibration file
				bool stereo_calib = false;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == false)
				{
					capL.release();
					capR.release();
					fl_alert("False calibration file! NOT compatible to STEREO system!");
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					capL.release();
					capR.release();
					fl_alert("Cannot do calibration!");
					return;
				}
			} else {
				capL.release();
				capR.release();
				fl_alert("Cannot read calibration file!");
				return;
			}
		}
	}
	
	// # SINGLE IMAGE FILE
	if(source_id == 6)
	{
		// # Set single flag
		single = true;
		// # Set MONO flag
		stereo = false;
		// # Set video/cam flag
		videocam = false;
		
		// # Image Sequence
		// Test by opening the image and close it
		const char * filename_test = txtParamA->value();
		Mat A = imread(filename_test);
		if(A.data == NULL)
		{
			// error
			fl_alert("Cannot read single image!");
			return;	
		}
		
		// Get properties
		// get image resolution
		//int w = A.cols;
		//int h = A.rows;
		
		// close it
		A.release();
		
		// set default FPS to 10
		FPS = 0; // you can change this later, no problem
		// set sequence start
		start_count = 0;
		// set total count
		total_count = 1; // single image
		
		// disabled
		// check for resolution must be 640x480
		//if(w!=640 || h!=480)
		//{
			//fl_alert("Image resolution is not 640x480!");
			//return;
		//}
		
		// copy filename to system storage
		filename_single = (char*)calloc( strlen(filename_test)+1 , sizeof(char)); // L
			strcpy( filename_single , filename_test );
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// check for stereo flag in calibration file
				bool stereo_calib = false;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == false)
				{
					fl_alert("False calibration file! NOT compatible to STEREO system!");
					free(filename_single);
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					fl_alert("Cannot do calibration!");
					free(filename_single);
					return;
				}
			} else {
				fl_alert("Cannot read calibration file!");
				free(filename_single);
				return;
			}
		}
		
	}
	
	// # STEREO IMAGE FILE
	if(source_id == 7)
	{
		// # Set single flag
		single = true;
		// # Set STEREO flag
		stereo = true;
		// # Set video/cam flag
		videocam = false;
		
		// # Image Sequence
		// Test by opening the image and close it
		const char * filename_left = txtParamA->value();
		const char * filename_right = txtParamB->value();
		Mat A = imread(filename_left);
		Mat B = imread(filename_right);
		if(A.data == NULL || B.data == NULL)
		{
			// error
			fl_alert("Cannot read stereo image!");
			return;	
		}
		
		// Get properties
		// get image resolution
		//int w = (A.cols + B.cols)/2;
		//int h = (A.rows + B.rows)/2;
		
		// close it
		A.release();
		B.release();
		
		// set default FPS to 10
		FPS = 0; // you can change this later, no problem
		// set sequence start
		start_count = 0;
		// set total count
		total_count = 1; // single image
		
		// copy filename to system storage
		filename_stereo = (char**) calloc( 2 , sizeof(char*));
		filename_stereo[0] = (char*)calloc( strlen(filename_left)+1 , sizeof(char)); // L
			strcpy( filename_stereo[0] , filename_left );
		filename_stereo[1] = (char*)calloc( strlen(filename_right)+1 , sizeof(char)); // R
			strcpy( filename_stereo[1] , filename_right );
		
		// check for calibration file
		// if supplied
		calibrated = false;
		if(strlen(txtParamC->value()) > 0)
		{
			// test by open it and close it
			FileStorage fs(txtParamC->value(), FileStorage::READ);
			if( fs.isOpened() ) // if we have file with parameters, read them
			{
				// check for stereo flag in calibration file
				bool stereo_calib = false;
				fs["stereo"] >> stereo_calib;
				if(stereo_calib == false)
				{
					fl_alert("False calibration file! NOT compatible to STEREO system!");
					free(filename_stereo[0]);
					free(filename_stereo[1]);
					free(filename_stereo);
					return;
				}
			
				// OK!
				fs.release();
				// run function
				if(calibration_func(txtParamC->value()) == false)
				{
					fl_alert("Cannot do calibration!");
					free(filename_stereo[0]);
					free(filename_stereo[1]);
					free(filename_stereo);
					return;
				}
			} else {
				fl_alert("Cannot read calibration file!");
				free(filename_stereo[0]);
				free(filename_stereo[1]);
				free(filename_stereo);
				return;
			}
		}
		
	}
	
	//------------------------------------------------------------------
	// INIT VARS & ENABLE MAIN FORM
	
	// init vars
	counter = start_count;
	progBar->maximum(total_count);
	progBar->value(0);
	stage->enable = false;
	stage->source = &fltk_frame;
	char tmpstr[100];
	sprintf(tmpstr,"%d", FPS);
	txtFPS->value(tmpstr);
	
	// set status info
	lblStatus->copy_label("");
	
	// disable FPS and pause button if single image mode is used
	// hide progressbar too
	if(single == true)
	{
		btnPause->deactivate();
		txtFPS->deactivate();
		progBar->hide();
	}
	
	// enable main form, hide startup/setup form
	frmSetup->hide();
	
	// call init_ok function to main.cpp
	init_ok();
}

void cb_btnBlank() {
	txtParamA->value("");
	txtParamB->value("");
	txtParamC->value("");
	
	txtUSBCw->value("");
	txtUSBCh->value("");
	txtUSBCFOURCC->value("");
	chkSkipRectifyUndistort->value(false);
}

void cb_btnLoad() {
	// load using FLTK preferences
	Fl_Preferences pref(".", "Jonathan Chandra", SETUPFILE_KEYWORD);
	
		unsigned int len = txtParamA->maximum_size();
		char tmpstr[len+1];
	
		int cmbidx;
		pref.get("IndexSource",cmbidx,0);
		cmbSource->value(cmbidx);
		
		pref.get("ParamA",tmpstr,"",len);
			txtParamA->value(tmpstr);
		
		pref.get("ParamB",tmpstr,"",len);
			txtParamB->value(tmpstr);
			
		pref.get("ParamC",tmpstr,"",len);
			txtParamC->value(tmpstr);
			
		pref.get("CameraW",tmpstr,"",len);
			txtUSBCw->value(tmpstr);
		pref.get("CameraH",tmpstr,"",len);
			txtUSBCh->value(tmpstr);
		pref.get("CameraFourCC",tmpstr,"",len);
			txtUSBCFOURCC->value(tmpstr);
		pref.get("SkipRectifyUndistort",tmpstr,"0",len);
			chkSkipRectifyUndistort->value(strtol(tmpstr,NULL,10));
}

void cb_btnSave() {
	// confirmation box
	if(fl_choice("Are you sure?", NULL, "Yes", "No") == 2)
	{
		//fl_alert("Cancelled");
		return;
	}
	
	// save using FLTK preferences
	Fl_Preferences pref(".", "Jonathan Chandra", SETUPFILE_KEYWORD);
		pref.set("IndexSource",cmbSource->value());
		pref.set("ParamA",txtParamA->value());
		pref.set("ParamB",txtParamB->value());
		pref.set("ParamC",txtParamC->value());
		pref.set("CameraW",txtUSBCw->value());
		pref.set("CameraH",txtUSBCh->value());
		pref.set("CameraFourCC",txtUSBCFOURCC->value());
		pref.set("SkipRectifyUndistort",chkSkipRectifyUndistort->value());
	pref.flush();
}


//======================================================================
// Functions

bool calibration_func(const char * filename) {
	calibrated = false;
	specific_calibrated = false;
	
	// Read file and set into vars
	cout << "Reading calibration file..." << endl;
	FileStorage fs(txtParamC->value(), FileStorage::READ);
	if(fs.isOpened() == false)
	{
		fl_alert("Error, cannot read stereo calibration file!");
		return false;
	}
		//string date;
		//fs["calibrationDate"] >> date;
		//	cout << "Calibration Date : " << date << endl;
		fs["cameraMatrixL"] >> intrinsicL;
			cout << "Camera Matrix Left : " << endl << intrinsicL << endl;
		fs["cameraMatrixR"] >> intrinsicR;
			cout << "Camera Matrix Right : " << endl << intrinsicR << endl;
		fs["distCoeffsL"] >> distCoeffsL;
			cout << "DistCoeffs Left : " << endl << distCoeffsL << endl;
		fs["distCoeffsR"] >> distCoeffsR;
			cout << "DistCoeffs Right : " << endl << distCoeffsR << endl;
		// Not used.
		//fs["monoRv"] >> monoRvect; // multiple vector
		//fs["monoTv"] >> monoTvect; // multiple vector
		fs["Rv"] >> Rvect;
			cout << "Rotation vector : " << endl << Rvect << endl;
		fs["Tv"] >> Tvect;
			cout << "Translation vector : " << endl << Tvect << endl;
		fs["E"] >> Emat;
			cout << "Essential : " << endl << Emat << endl;
		fs["F"] >> Fmat;	
			cout << "Fundamental : " << endl << Fmat << endl;
	fs.release();
	cout << "done." << endl;
	
	// Stereo system, init rectify and undistort
	if(stereo == true && chkSkipRectifyUndistort->value() == false)
	{
		// vars for stereo rectification
		cout << "Rectifying stereo calib... ";
		//Mat RectifyL; // out
		//Mat RectifyR; // out
		//Mat ProjectL; // out
		//Mat ProjectR; // out
		//Mat Qdepth; // out depth
		// stereo rectification
		Mat tmpframe;
		if(single == false)
		{
			// normal / multiple frame
			if(videocam == true)
			{
				// webcam
				capL >> tmpframe;
			} else {
				// sequence image
				tmpframe = imread(filenameL_seq[0]);
			}
			if(tmpframe.data == NULL)
			{
				fl_alert("Calibration, rectification failed!\nCannot read frame!");
				return false;
			}
		} else {
			// single frame
			tmpframe = imread(filename_stereo[0]); // left image
			if(tmpframe.data == NULL)
			{
				fl_alert("Calibration, rectification failed!\nCannot read image!");
				return false;
			}
		}
		stereoRectify(
			intrinsicL, distCoeffsL,
			intrinsicR, distCoeffsR,
			tmpframe.size(),
			Rvect, Tvect,
			RectifyL, RectifyR,
			ProjectL, ProjectR,
			Qdepth
		);
		cout << "done." << endl;
		
		
		cout << "Initializing UndistortionRectifyMap... ";
		//Mat mapLx, mapLy, mapRx, mapRy; // output
		{
			Mat tmpFrameL; Mat tmpFrameR;
			if(single == false)
			{
				// normal / multiframe
				if(videocam == true)
				{
					// VideoWebcam only or AVI
					capL >> tmpFrameL; // capture first frame
					capR >> tmpFrameR; // capture first frame
				} else {
					// sequenced images
					tmpFrameL = imread( filenameL_seq[0] );
					tmpFrameR = imread( filenameR_seq[0] );
				}
				if(tmpFrameL.data == NULL || tmpFrameR.data == NULL)
				{
					fl_alert("Calibration, undistort failed!\nCannot read frame!");
					return false;
				}
			} else {
				// single frame
				tmpFrameL = imread(filename_stereo[0]);
				tmpFrameR = imread(filename_stereo[1]);
				if(tmpFrameL.data == NULL || tmpFrameR.data == NULL)
				{
					fl_alert("Calibration, undistort failed!\nCannot read inages!");
					return false;
				}
			}
			initUndistortRectifyMap(intrinsicL, distCoeffsL, RectifyL, 
						ProjectL, tmpFrameL.size(), CV_32FC1, mapLx, mapLy);
			initUndistortRectifyMap(intrinsicR, distCoeffsR, RectifyR, 
						ProjectR, tmpFrameR.size(), CV_32FC1, mapRx, mapRy);
		}
		cout << "done." << endl;
	}
	
	// Stereo system, read Projection matrix and Q Matrix directly!
	if(stereo == true && chkSkipRectifyUndistort->value() == true)
	{
		// set flag
		specific_calibrated = true;
		
		cout << "Loading projection matrix and Q matrix... ";
		FileStorage fs(txtParamC->value(), FileStorage::READ);
		if(fs.isOpened() == false)
		{
			fl_alert("Error, cannot read stereo calibration file!");
			return false;
		}
		fs["RectifyL"] >> RectifyL;
			cout << "RectifyL : " << endl << RectifyL << endl;
		fs["RectifyR"] >> RectifyR;
			cout << "RectifyR : " << endl << RectifyR << endl;
		fs["ProjectL"] >> ProjectL;
			cout << "ProjectL : " << endl << ProjectL << endl;
		fs["ProjectR"] >> ProjectR;
			cout << "ProjectR : " << endl << ProjectR << endl;
		fs["Q"] >> Qdepth;
			cout << "Q : " << endl << Qdepth << endl;
		cout << "done" << endl;
	}
	
	calibrated = true;
	return true;
}

bool iter() {
	
// --- MONO ---

	// # TYPE WEBCAM / CAMERA
	if(source_id == 0)
	{
		// get frame
		Mat raw;
		cap.read(raw);
		if(raw.data == NULL)
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set information
		progBar->value(0);
		lblStatus->copy_label("Streaming from camera...");
		
		// processing here ...
		// APPLY YOUR CODE HERE
		if( process(&raw) == false )
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set result
		frame = raw;
		
		// free
		raw.release();
	}
	
	// # TYPE IMAGE SEQUENCE
	if(source_id == 1)
	{
		// {STOP WHEN FINAL FRAME}
		if(counter > total_count-1)
		{
			// call to stop
			btnRun->value(0);
			cb_btnRun(); // call to disable
			return false;
		}
	
		// get frame
		Mat raw;
		raw = imread( filename_seq[counter-start_count] );
		if(raw.data == NULL)
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set information
		char tmpstr[100];
		sprintf(tmpstr, "Sequencing image... %ld of %ld" , counter, total_count-1); 
		lblStatus->copy_label(tmpstr);
		progBar->value(counter-start_count+1);
		counter++;
		
		// processing here ...
		// APPLY YOUR CODE HERE
		if( process(&raw) == false )
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set result
		frame = raw;
		
		// free
		raw.release();
	}
	
	// # TYPE AVI VIDEO
	if(source_id == 2)
	{	
		// {STOP WHEN FINAL FRAME}
		if(counter > total_count-1)
		{
			// call to stop
			btnRun->value(0);
			cb_btnRun(); // call to disable
			return false;
		}
	
		// get frame
		Mat raw;
		cap.read(raw);
		if(raw.data == NULL)
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set information
		char tmpstr[100];
		sprintf(tmpstr, "Playing AVI... %ld/%ld" , counter, total_count-1); 
		lblStatus->copy_label(tmpstr);
		progBar->value(counter-start_count+1);
		counter++;
		
		// processing here ...
		// APPLY YOUR CODE HERE
		if( process(&raw) == false )
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set result
		frame = raw;
		
		// free
		raw.release();
	}
	
// --- STEREO ---

	// # TYPE WEBCAM / CAMERA
	if(source_id == 3 && stereo == true)
	{
		// get frame
		Mat rawL;
		capL.read(rawL);
		if(rawL.data == NULL)
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		Mat rawR;
		capR.read(rawR);
		if(rawR.data == NULL)
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set information
		progBar->value(0);
		lblStatus->copy_label("Streaming from stereo camera...");
		
		// processing here ...
		// APPLY YOUR CODE HERE
		if( process_stereo(&rawL, &rawR) == false )
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set result
		frame = rawL;
		
		// free
		rawL.release();
		rawR.release();
	}
	
	// # TYPE IMAGE SEQUENCE
	if(source_id == 4 && stereo == true)
	{
		// {STOP WHEN FINAL FRAME}
		if(counter > total_count-1)
		{
			// call to stop
			btnRun->value(0);
			cb_btnRun(); // call to disable
			return false;
		}
	
		// get frame
		Mat rawL;
		rawL = imread( filenameL_seq[counter-start_count] );
		if(rawL.data == NULL)
		{
			// stop
			fl_alert("Cannot read LEFT image!");
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		Mat rawR;
		rawR = imread( filenameR_seq[counter-start_count] );
		if(rawR.data == NULL)
		{
			// stop
			fl_alert("Cannot read RIGHT image!");
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set information
		char tmpstr[100];
		sprintf(tmpstr, "Sequencing stereo image... %ld of %ld" , counter, total_count-1); 
		lblStatus->copy_label(tmpstr);
		progBar->value(counter-start_count+1);
		counter++;
		
		// processing here ...
		// APPLY YOUR CODE HERE
		if( process_stereo(&rawL, &rawR) == false )
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set result
		frame = rawL;
		
		// free
		rawL.release();
		rawR.release();
	}
	
	// # TYPE AVI VIDEO
	if(source_id == 5 && stereo == true)
	{	
		// {STOP WHEN FINAL FRAME}
		if(counter > total_count-1)
		{
			// call to stop
			btnRun->value(0);
			cb_btnRun(); // call to disable
			return false;
		}
	
		// get frame
		Mat rawL;
		capL.read(rawL);
		if(rawL.data == NULL)
		{
			// stop
			fl_alert("Cannot read LEFT video!");
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		Mat rawR;
		capR.read(rawR);
		if(rawR.data == NULL)
		{
			// stop
			fl_alert("Cannot read RIGHT video!");
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set information
		char tmpstr[100];
		sprintf(tmpstr, "Playing stereo AVI... %ld/%ld" , counter, total_count-1); 
		lblStatus->copy_label(tmpstr);
		progBar->value(counter-start_count+1);
		counter++;
		
		// processing here ...
		// APPLY YOUR CODE HERE
		if( process_stereo(&rawL, &rawR) == false )
		{
			// stop
			btnRun->value(0);
			cb_btnRun();
			return false;
		}
		
		// set result
		frame = rawL;
		
		// free
		rawL.release();
		rawR.release();
	}
	
// --- --- ---
	// copy to our FLTK output
	cvtColor(frame, fltk_frame, CV_BGR2RGB);
	// enable to draw
	stage->enable = true;
	stage->redraw();
	return true;
}

void iter_single()
{
	
	// # TYPE SINGLE IMAGE
	if(source_id == 6 && stereo == false)
	{
		// load image
		Mat img;
		img = imread( filename_single );
		if(img.data == NULL)
		{
			fl_alert("Cannot read images!");
			return;
		}
		
		// set status info
		lblStatus->copy_label("Single image mode");
		
		// call process
		single_process(&img);
		
		// set result
		frame = img;
	}
	
	// # TYPE SINGLE STEREO IMAGE
	if(source_id == 7 && stereo == true)
	{
		// load image L and R
		Mat imgL;
		Mat imgR;
		imgL = imread( filename_stereo[0] );
		imgR = imread( filename_stereo[1] );
		if(imgL.data == NULL || imgR.data == NULL)
		{
			fl_alert("Cannot read images!");
			return;
		}
		
		// set status info
		lblStatus->copy_label("Stereo image mode");
		
		// call process
		single_process_stereo(&imgL, &imgR);
		
		// set result
		frame = imgL;
	}
	
	//-----------------------------------------------------
	// copy to our FLTK output
	cvtColor(frame, fltk_frame, CV_BGR2RGB);
	// enable to draw
	stage->enable = true;
	stage->redraw();
}

void cleanup() {
	stage->enable = false;
	Fl::remove_timeout(timer, NULL);
	// call user defined
	func_cleanupExit();
	// single source, sequence
	if(videocam == false && stereo == false && single==false)
	{
		clear_sequenceFiles();
	}
	// stereo source, sequence
	if(videocam == false && stereo == true && single==false)
	{
		clear_sequenceStereoFiles();
	}
	// stereo source, webcam
	if(videocam == true && stereo == true && single==false)
	{
		capL.release(); capR.release();
	}
	// single source, webcam
	if(videocam == true && stereo == false && single==false)
	{
		cap.release();
	}
	// single image
	if(single == true && stereo == false)
	{
		free(filename_single);
	}
	// stereo images
	if(single == true && stereo == true)
	{
		free(filename_stereo[0]);
		free(filename_stereo[1]);
		free(filename_stereo);
	}
}

void clear_sequenceFiles()
{
	for(long i = 0 ; i < total_count ; i++)
	{
		// MONO / SINGLE
		free(filename_seq[i]);
	}
	free(filename_seq);
}

void clear_sequenceStereoFiles()
{
	for(long i = 0 ; i < total_count ; i++)
	{
		if(stereo == false)
		{
			// MONO / SINGLE
			free(filename_seq[i]);
		} else {
			// STEREO
			free(filenameL_seq[i]);
			free(filenameR_seq[i]);
		}
	}
	free(filenameL_seq);
	free(filenameR_seq);
}

/*
bool process(Mat *img) {
	Mat undistort_img;
	// undistort (if calibration is supplied)
	if(calibrated == true)
	{
		undistort(*img, undistort_img, intrinsicL, distCoeffsL);
	}
	// Add your code here [Mono Source]



	return true;
}

bool process_stereo(Mat *imgL, Mat *imgR) {
	Mat undistort_imgL; Mat undistort_imgR;
	// rectify and undistort (if calibration is supplied)
	if(calibrated == true)
	{
		remap(*imgL, undistort_imgL, mapLx, mapLy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
		remap(*imgR, undistort_imgR, mapRx, mapRy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
	}
	// Add your code here [Stereo Source]
	
	 
	
	return true;
}

void single_process(Mat *img)
{
	// Add your code here [single frame/image]
	
	
	
	return;
}

void single_process_stereo(Mat *imgL, Mat *imgR)
{
	// Add you code here [single frame/ stereo image]
	
	
	
	return;
}

void init_ok()
{
	// when initialization / frmSetup is done
	// add your code here..
	
	
	
}

*/


