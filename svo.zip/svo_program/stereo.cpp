//
/*
 *	OpenCV Stereo Visual Odometry
 * 	by Jonathan Chandra (c) 2016
 * 
 * Stereo camera, 
 * menghitung StereoBM atau StereoSGBM dan menghasilkan disparity map
 * points triangulation dan filter 3D points
 * 	
 */
//

#include "stereo.h"

using namespace std;
using namespace cv;

// # BM -- Block Matching
Mat do_StereoBM(Mat *imgL, Mat *imgR, Mat *disp32F)
{
	// calculate disparity map

	// NOT USED ANYMORE, INPUT MUST BE RECTIFIED AND CALIBRATED
	/*
	// undistort using calibration matrix
	Mat undistort_frameL;
	Mat undistort_frameR;
	if(strlen(txtParamC->value()) > 0) // calibration enabled
	{
		// re-map
		remap(*imgL, undistort_frameL, mapLx, mapLy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
		remap(*imgR, undistort_frameR, mapRx, mapRy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
	} else {
		// copy directly
		undistort_frameL = *imgL;
		undistort_frameR = *imgR;
	}
	*/
	
		// convert to grayscale
		Mat gray_UframeL;
		Mat gray_UframeR;
		cvtColor(*imgL, gray_UframeL, CV_BGR2GRAY);
		cvtColor(*imgR, gray_UframeR, CV_BGR2GRAY);
		
		// calculate STEREO CORRESPONDENCE USING BLOCK MATCHING
		// StereoBM init
		int ndisparities = (int)sldBM_ndisparities->value(); //16*4; // < Range of disparity 16*5
		int SADWindowSize = (int)sldBM_SADwindowsize->value(); //21; // < Size of the block window. Must be odd  21
		Ptr<StereoBM> sbm = StereoBM::create( ndisparities, SADWindowSize );
			sbm->setPreFilterCap((int)sldBM_prefilterCap->value());
			sbm->setPreFilterSize((int)sldBM_prefilterSize->value());
			sbm->setUniquenessRatio((int)sldBM_uniqueness->value());
			sbm->setTextureThreshold((int)sldBM_textureThreshold->value());
			sbm->setSpeckleWindowSize((int)sldBM_specklewinsize->value());
			sbm->setSpeckleRange((int)sldBM_specklewinrng->value());
			sbm->setMinDisparity((int)sldBM_mindisparity->value());
			sbm->setDisp12MaxDiff((int)sldBM_maxdiff->value());
			
		// compute
		Mat imgDisparity16S = Mat( gray_UframeL.rows, gray_UframeL.cols, CV_16S ); // signed
		Mat imgDisparity32F = Mat( gray_UframeL.rows, gray_UframeL.cols, CV_32F ); // float
		sbm->compute( gray_UframeL, gray_UframeR, imgDisparity16S );
				
		// conversion from 16bit signed to 32bit floating point
		// convert to 32F, so don't divide by 16 to get real disparity value
		imgDisparity16S.convertTo( imgDisparity32F, CV_32F, 1./16.);
		
		// show the disparity image
		// WARNING: GRAY IMAGE
		// imgDisparity8U;	

	*disp32F = imgDisparity32F;
	double minVal; double maxVal;
	minMaxLoc( imgDisparity32F, &minVal, &maxVal );
	//cout << "Min disp: " << minVal << " Max value: " << maxVal << endl;
	// Display it as a CV_8UC1 image
	Mat imgDisparity8U;
	imgDisparity32F.convertTo( imgDisparity8U, CV_8UC1, 255/(maxVal - minVal));
	Mat result;
	cvtColor(imgDisparity8U, result, CV_GRAY2BGR);
	return result;
}

// # SGBM -- Semi Global Block Matching
Mat do_StereoSGBM(Mat *imgL, Mat *imgR, Mat * disp32F)
{
	// calculate disparity map

	// NOT USED ANYMORE, INPUT MUST BE RECTIFIED AND CALIBRATED
	/*
	// undistort using calibration matrix
	Mat undistort_frameL;
	Mat undistort_frameR;
	if(strlen(txtParamC->value()) > 0) // calibration enabled
	{
		// remove distortion
		remap(*imgL, undistort_frameL, mapLx, mapLy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
		remap(*imgR, undistort_frameR, mapRx, mapRy, INTER_LINEAR, BORDER_CONSTANT, Scalar());
	} else {
		// copy directly
		undistort_frameL = *imgL;
		undistort_frameR = *imgR;
	}
	*/
			
		// convert to grayscale
		Mat gray_UframeL;
		Mat gray_UframeR;
		cvtColor(*imgL, gray_UframeL, CV_BGR2GRAY);
		cvtColor(*imgR, gray_UframeR, CV_BGR2GRAY);
		
		// calculate STEREO CORRESPONDENCE USING BLOCK MATCHING
		// StereoBM init
		int mindisparities = (int)sldBM_mindisparity->value();
		int ndisparities = (int)sldBM_ndisparities->value(); //16*4; // < Range of disparity 16*5
		int SADWindowSize = (int)sldBM_SADwindowsize->value(); //21; // < Size of the block window. Must be odd  21
		Ptr<StereoSGBM> sgbm = StereoSGBM::create( mindisparities, ndisparities, SADWindowSize );
			sgbm->setP1((int)sldSGBM_P1->value());
			sgbm->setP2((int)sldSGBM_P2->value());
			sgbm->setDisp12MaxDiff((int)sldBM_maxdiff->value());
			sgbm->setPreFilterCap((int)sldBM_prefilterCap->value());
			sgbm->setUniquenessRatio((int)sldBM_uniqueness->value());
			sgbm->setSpeckleWindowSize((int)sldBM_specklewinsize->value());
			sgbm->setSpeckleRange((int)sldBM_specklewinrng->value());
			sgbm->setMode( false ); // if true, huge data - slow	
			
			//sgbm->setPreFilterSize((int)sldSGBM_prefilterSize->value());
			//sgbm->setTextureThreshold((int)sldSGBM_textureThreshold->value());
			
		// compute
		Mat imgDisparity16S = Mat( gray_UframeL.rows, gray_UframeL.cols, CV_16S ); // 16bit signed
		Mat imgDisparity32F = Mat( gray_UframeL.rows, gray_UframeL.cols, CV_32F ); // float
		sgbm->compute( gray_UframeL, gray_UframeR, imgDisparity16S );
		
		// conversion from 16bit signed to 32bit floating point
		// convert to 32F, so don't divide by 16 to get real disparity value
		imgDisparity16S.convertTo( imgDisparity32F, CV_32F, 1./16.);
		
		// show the disparity image
		// WARNING: GRAY IMAGE
		// imgDisparity8U;	

	*disp32F = imgDisparity32F;
	double minVal; double maxVal;
	minMaxLoc( imgDisparity32F, &minVal, &maxVal );
	//cout << "Min disp: " << minVal << " Max value: " << maxVal << endl;
	// Display it as a CV_8UC1 image
	Mat imgDisparity8U;
	imgDisparity32F.convertTo( imgDisparity8U, CV_8UC1, 255/(maxVal - minVal));
	Mat result;
	cvtColor(imgDisparity8U, result, CV_GRAY2BGR);
	return result;
}

// Reset stereo settings
void resetParams_Stereo()
{
	sldBM_ndisparities->value(80);
	sldBM_SADwindowsize->value(21);
	sldBM_prefilterSize->value(7);
	sldBM_prefilterCap->value(21);
	sldBM_textureThreshold->value(0);	
	sldBM_uniqueness->value(0);
	sldBM_maxdiff->value(0);
	sldBM_specklewinsize->value(50);
	sldBM_specklewinrng->value(10);
	sldBM_mindisparity->value(0);
	sldSGBM_P1->value(0);
	sldSGBM_P2->value(0);
}

// Save to FLTK Preferences
void saveParams_Stereo()
{
	// create root setting point
	Fl_Preferences settings = Fl_Preferences( ".", "Jonathan Chandra OpenCV 2016", "DisparityMap" );
	settings.set("AppVersion", "0.1");
	settings.set("Copyright", "Jonathan Chandra (c) 2016");

	// create sub-child
	Fl_Preferences BM = Fl_Preferences( settings, "StereoBM" );
		BM.set("ndisparities", sldBM_ndisparities->value());
		BM.set("SADwindowsize", sldBM_SADwindowsize->value());
		BM.set("prefilterSize", sldBM_prefilterSize->value());
		BM.set("prefilterCap", sldBM_prefilterCap->value());
		BM.set("textureThreshold", sldBM_textureThreshold->value());	
		BM.set("uniqueness", sldBM_uniqueness->value());
		BM.set("maxdiff", sldBM_maxdiff->value());
		BM.set("specklewinsize", sldBM_specklewinsize->value());
		BM.set("specklewinrng", sldBM_specklewinrng->value());
		BM.set("mindisparity", sldBM_mindisparity->value());
	
	// create sub-child
	Fl_Preferences SGBM( settings, "StereoSGBM" ); // this another example declaration
		//SGBM.set("ndisparities", sldBM_ndisparities->value());
		//SGBM.set("SADwindowsize", sldBM_SADwindowsize->value());
		//SGBM.set("prefilterCap", sldBM_prefilterCap->value());
		SGBM.set("P1", sldSGBM_P1->value());
		SGBM.set("P2", sldSGBM_P2->value());
		//SGBM.set("uniqueness", sldBM_uniqueness->value());
		//SGBM.set("maxdiff", sldBM_maxdiff->value());
		//SGBM.set("specklewinsize", sldBM_specklewinsize->value());
		//SGBM.set("specklewinrng", sldBM_specklewinrng->value());
		//SGBM.set("mindisparity", sldBM_mindisparity->value());	
}

// Load from FLTK Preferences
void loadParams_Stereo()
{
	double dval;

	// create root setting point
	Fl_Preferences settings = Fl_Preferences( ".", "Jonathan Chandra OpenCV 2016", "DisparityMap" );
	//settings.get("AppVersion", tmpstr, "?", 1023); frmMain->copy_label(tmpstr);
	//settings.get("Copyright", tmpstr, "!", 1023); strcat(tmpstr, " ; AppVer "); strcat( tmpstr, frmMain->label() ); frmMain->copy_label(tmpstr);
		
	// create sub-child
	Fl_Preferences BM( settings, "StereoBM" ); // this another example declaration	
		BM.get("ndisparities", dval, 80);	sldBM_ndisparities->value(dval);
		BM.get("SADwindowsize", dval, 21);	 sldBM_SADwindowsize->value(dval);
		BM.get("prefilterSize", dval, 7);	 sldBM_prefilterSize->value(dval);
		BM.get("prefilterCap", dval, 21);	 sldBM_prefilterCap->value(dval);
		BM.get("textureThreshold", dval, 0);	 sldBM_textureThreshold->value(dval);	
		BM.get("uniqueness", dval, 0);	 sldBM_uniqueness->value(dval);
		BM.get("maxdiff", dval, 0);	 sldBM_maxdiff->value(dval);
		BM.get("specklewinsize", dval, 50);	 sldBM_specklewinsize->value(dval);
		BM.get("specklewinrng", dval, 10);	 sldBM_specklewinrng->value(dval);
		BM.get("mindisparity", dval, 0);	 sldBM_mindisparity->value(dval);
		
	// create sub-child
	Fl_Preferences SGBM( settings, "StereoSGBM" ); // this another example declaration
		//SGBM.get("ndisparities", dval, 80);	 sldBM_ndisparities->value(dval);
		//SGBM.get("SADwindowsize", dval, 11);	 sldBM_SADwindowsize->value(dval);
		//SGBM.get("prefilterCap", dval, 21);	 sldBM_prefilterCap->value(dval);
		SGBM.get("P1", dval, 0);	 sldSGBM_P1->value(dval);
		SGBM.get("P2", dval, 0);	 sldSGBM_P2->value(dval);
		//SGBM.get("uniqueness", dval, 0);	 sldBM_uniqueness->value(dval);
		//SGBM.get("maxdiff", dval, 5);	 sldBM_maxdiff->value(dval);
		//SGBM.get("specklewinsize", dval, 50);	 sldBM_specklewinsize->value(dval);
		//SGBM.get("specklewinrng", dval, 10);	 sldBM_specklewinrng->value(dval);
		//SGBM.get("mindisparity", dval, 0);	 sldBM_mindisparity->value(dval);
}

